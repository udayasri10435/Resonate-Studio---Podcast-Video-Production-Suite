import React from 'react';
import { TabType } from '../../types';
import { Radio, Download, Mic } from 'lucide-react';

interface TopBarProps {
  activeTab: TabType;
  onSelectTab: (tab: TabType) => void;
  onOpenExport: () => void;
  onStartNewRecording: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  activeTab,
  onSelectTab,
  onOpenExport,
  onStartNewRecording
}) => {
  return (
    <header className="h-14 border-b border-neutral-800/80 bg-neutral-950 px-6 flex items-center justify-between shrink-0">
      {/* Zone 1: Single text element wordmark */}
      <a
        href="#"
        onClick={(e) => {
          e.preventDefault();
          onSelectTab('editor');
        }}
        className="text-base font-bold tracking-tight text-neutral-100 hover:text-white transition-colors flex items-center gap-2"
      >
        <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
        <span>Resonate Studio</span>
      </a>

      {/* Zone 2: 4-6 clean text navigation links */}
      <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
        <button
          onClick={() => onSelectTab('studio')}
          className={`transition-colors whitespace-nowrap ${
            activeTab === 'studio'
              ? 'text-neutral-100 font-semibold'
              : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          Studio
        </button>

        <button
          onClick={() => onSelectTab('editor')}
          className={`transition-colors whitespace-nowrap ${
            activeTab === 'editor'
              ? 'text-neutral-100 font-semibold'
              : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          Editor
        </button>

        <button
          onClick={() => onSelectTab('transcription')}
          className={`transition-colors whitespace-nowrap ${
            activeTab === 'transcription'
              ? 'text-neutral-100 font-semibold'
              : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          Transcription
        </button>

        <button
          onClick={() => onSelectTab('distribution')}
          className={`transition-colors whitespace-nowrap ${
            activeTab === 'distribution'
              ? 'text-neutral-100 font-semibold'
              : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          Distribution
        </button>

        <button
          onClick={() => onSelectTab('monetization')}
          className={`transition-colors whitespace-nowrap ${
            activeTab === 'monetization'
              ? 'text-neutral-100 font-semibold'
              : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          Monetization
        </button>
      </nav>

      {/* Zone 3: 1-2 primary actions */}
      <div className="flex items-center gap-3">
        <button
          onClick={onStartNewRecording}
          className="px-3.5 py-1.5 text-xs font-semibold text-neutral-200 bg-neutral-900 border border-neutral-800 rounded-lg hover:bg-neutral-800 hover:text-white transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0"
        >
          <Mic className="w-3.5 h-3.5 text-rose-500" />
          <span>New Session</span>
        </button>

        <button
          onClick={onOpenExport}
          className="px-3.5 py-1.5 text-xs font-semibold text-white bg-neutral-100 hover:bg-white text-neutral-950 rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0 shadow-sm"
        >
          <Download className="w-3.5 h-3.5 text-neutral-950" />
          <span>Export Master</span>
        </button>
      </div>
    </header>
  );
};
