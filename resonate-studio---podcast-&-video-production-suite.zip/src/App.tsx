import React, { useState } from 'react';
import { initialEpisode } from './data/mockEpisode';
import { Episode, TabType, Track, TranscriptWord, VideoClip } from './types';
import { TopBar } from './components/layout/TopBar';
import { RecordingStudio } from './components/studio/RecordingStudio';
import { TextEditorTimeline } from './components/editor/TextEditorTimeline';
import { TranscriptionHub } from './components/transcription/TranscriptionHub';
import { DistributionHub } from './components/distribution/DistributionHub';
import { MonetizationHub } from './components/monetization/MonetizationHub';
import { ExportModal } from './components/modals/ExportModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('editor');
  const [episode, setEpisode] = useState<Episode>(initialEpisode);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);

  const handleUpdateEpisode = (updated: Partial<Episode>) => {
    setEpisode(prev => ({ ...prev, ...updated }));
  };

  const handleFinishRecording = (newTracks: Track[], newWords: TranscriptWord[]) => {
    setEpisode(prev => ({
      ...prev,
      tracks: newTracks,
      transcript: newWords,
      status: 'editing'
    }));
  };

  const handleAddShortsClip = (clip: VideoClip) => {
    setEpisode(prev => ({
      ...prev,
      clips: [clip, ...prev.clips]
    }));
  };

  return (
    <div className="h-screen w-screen flex flex-col bg-neutral-950 text-neutral-100 overflow-hidden font-sans">
      {/* Top Bar Navigation (Contract: Brand, Links, Primary Action) */}
      <TopBar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onOpenExport={() => setIsExportModalOpen(true)}
        onStartNewRecording={() => setActiveTab('studio')}
      />

      {/* Main Suite Content Viewport */}
      <main className="flex-1 overflow-hidden relative">
        {activeTab === 'studio' && (
          <RecordingStudio
            episode={episode}
            onFinishRecording={handleFinishRecording}
            onNavigateToEditor={() => setActiveTab('editor')}
          />
        )}

        {activeTab === 'editor' && (
          <TextEditorTimeline
            episode={episode}
            onUpdateEpisode={handleUpdateEpisode}
            onAddShortsClip={handleAddShortsClip}
          />
        )}

        {activeTab === 'transcription' && (
          <TranscriptionHub
            episode={episode}
            onUpdateEpisode={handleUpdateEpisode}
            onAddShortsClip={handleAddShortsClip}
            onSelectTab={setActiveTab}
          />
        )}

        {activeTab === 'distribution' && (
          <DistributionHub
            episode={episode}
            onUpdateEpisode={handleUpdateEpisode}
          />
        )}

        {activeTab === 'monetization' && (
          <MonetizationHub
            episode={episode}
            onUpdateEpisode={handleUpdateEpisode}
          />
        )}
      </main>

      {/* Export Modal */}
      <ExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        episode={episode}
      />
    </div>
  );
}
