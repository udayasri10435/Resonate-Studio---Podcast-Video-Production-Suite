import React, { useState } from 'react';
import { 
  Radio, Globe, Play, Pause, RotateCcw, FastForward, 
  ExternalLink, Copy, Check, Code, Share2, Rss, 
  CheckCircle2, Clock, Volume2, ShieldCheck, Eye
} from 'lucide-react';
import { Episode } from '../../types';

interface DistributionHubProps {
  episode: Episode;
  onUpdateEpisode: (updated: Partial<Episode>) => void;
}

export const DistributionHub: React.FC<DistributionHubProps> = ({
  episode,
  onUpdateEpisode
}) => {
  const [activeTab, setActiveTab] = useState<'platforms' | 'rss' | 'embed' | 'webpage'>('platforms');
  const [copiedType, setCopiedType] = useState<string | null>(null);

  // Embed player state
  const [embedPlaying, setEmbedPlaying] = useState(false);
  const [embedProgress, setEmbedProgress] = useState(25); // percentage
  const [embedSpeed, setEmbedSpeed] = useState('1.0x');

  const copyText = (text: string, label: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedType(label);
    setTimeout(() => setCopiedType(null), 2000);
  };

  // Generate real RSS 2.0 XML
  const rssXml = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" 
     xmlns:itunes="http://www.itunes.com/dtds/podcast-1.0.dtd"
     xmlns:content="http://purl.org/rss/1.0/modules/content/">
  <channel>
    <title>The Tech Frontier</title>
    <link>https://resonate.studio/show/the-tech-frontier</link>
    <language>en-us</language>
    <itunes:author>Marcus Vance</itunes:author>
    <itunes:summary>${episode.subtitle}</itunes:summary>
    <itunes:category text="Technology"/>
    <itunes:explicit>false</itunes:explicit>
    <itunes:image href="https://resonate.studio/covers/ep-042.jpg"/>
    
    <item>
      <title>${episode.title}</title>
      <itunes:episode>${episode.episodeNumber}</itunes:episode>
      <itunes:season>${episode.season}</itunes:season>
      <pubDate>Tue, 29 Sep 2026 10:30:00 GMT</pubDate>
      <enclosure url="https://cdn.resonate.studio/audio/ep-042-master.mp3" 
                 length="48529100" 
                 type="audio/mpeg"/>
      <itunes:duration>${episode.duration}</itunes:duration>
      <guid isPermaLink="false">resonate-ep-${episode.id}</guid>
      <description><![CDATA[${episode.showNotes.summary}]]></description>
    </item>
  </channel>
</rss>`;

  return (
    <div className="h-full flex flex-col bg-neutral-950 text-neutral-100 overflow-hidden">
      {/* Header */}
      <div className="h-14 border-b border-neutral-800 px-6 flex items-center justify-between bg-neutral-900/60 shrink-0">
        <div className="flex items-center gap-3">
          <Radio className="w-4 h-4 text-blue-400" />
          <span className="font-semibold text-sm text-neutral-100">Distribution & Multi-Platform Syndication</span>
          <span className="text-neutral-700">·</span>
          <span className="text-xs text-neutral-400">
            One-click syndication to Spotify, Apple, YouTube, and Global RSS Feeds
          </span>
        </div>

        {/* Sub-navigation */}
        <div className="flex items-center bg-neutral-900 border border-neutral-800 rounded-md p-0.5 text-xs">
          <button
            onClick={() => setActiveTab('platforms')}
            className={`px-3 py-1.5 rounded transition-colors ${activeTab === 'platforms' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400 hover:text-neutral-200'}`}
          >
            Syndication Hub
          </button>
          <button
            onClick={() => setActiveTab('rss')}
            className={`px-3 py-1.5 rounded transition-colors ${activeTab === 'rss' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400 hover:text-neutral-200'}`}
          >
            RSS Feed 2.0
          </button>
          <button
            onClick={() => setActiveTab('embed')}
            className={`px-3 py-1.5 rounded transition-colors ${activeTab === 'embed' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400 hover:text-neutral-200'}`}
          >
            Embed Player
          </button>
          <button
            onClick={() => setActiveTab('webpage')}
            className={`px-3 py-1.5 rounded transition-colors ${activeTab === 'webpage' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400 hover:text-neutral-200'}`}
          >
            Episode Landing Page
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto p-6 max-w-5xl mx-auto w-full">
        {/* TAB 1: PLATFORM SYNDICATION */}
        {activeTab === 'platforms' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
              <div>
                <h2 className="text-lg font-bold text-neutral-100">Broadcast Destination Channels</h2>
                <p className="text-xs text-neutral-400 mt-0.5">
                  Connected publishing destinations with direct API ingest.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="px-2.5 py-1 rounded bg-emerald-950/80 border border-emerald-500/30 text-emerald-400 text-xs font-medium flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  ID3 & Apple Audio Specs Validated
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Spotify */}
              <div className="bg-neutral-900/60 border border-neutral-800 rounded-lg p-5 flex flex-col justify-between hover:border-neutral-700 transition-colors">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-full bg-emerald-950/60 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-bold text-xs">
                        SP
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-neutral-100">Spotify for Podcasters</h4>
                        <span className="text-xs text-neutral-500">Audio & Full 1080p Video Ingest</span>
                      </div>
                    </div>
                    <span className="text-xs px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-500/20 font-mono">
                      SYNCED
                    </span>
                  </div>
                  <p className="text-xs text-neutral-400 leading-relaxed">
                    Episode #42 synced. Dynamic chapter markers and video canvas exported to Spotify canvas cards.
                  </p>
                </div>

                <div className="pt-4 border-t border-neutral-800 flex items-center justify-between text-xs mt-4">
                  <span className="text-neutral-500 font-mono">Last Ingest: 12 min ago</span>
                  <button
                    onClick={() => alert('Updated Spotify metadata!')}
                    className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 rounded text-neutral-200 font-medium"
                  >
                    Re-Sync Episode
                  </button>
                </div>
              </div>

              {/* Apple Podcasts */}
              <div className="bg-neutral-900/60 border border-neutral-800 rounded-lg p-5 flex flex-col justify-between hover:border-neutral-700 transition-colors">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-full bg-purple-950/60 border border-purple-500/30 flex items-center justify-center text-purple-400 font-bold text-xs">
                        AP
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-neutral-100">Apple Podcasts Connect</h4>
                        <span className="text-xs text-neutral-500">Apple Podcasts Subscriptions Ready</span>
                      </div>
                    </div>
                    <span className="text-xs px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-500/20 font-mono">
                      SYNCED
                    </span>
                  </div>
                  <p className="text-xs text-neutral-400 leading-relaxed">
                    Standard feed ingested with Apple chapter frames and listener subscriber premium tier support.
                  </p>
                </div>

                <div className="pt-4 border-t border-neutral-800 flex items-center justify-between text-xs mt-4">
                  <span className="text-neutral-500 font-mono">Status: Approved</span>
                  <button
                    onClick={() => alert('Apple Podcasts metadata verified!')}
                    className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 rounded text-neutral-200 font-medium"
                  >
                    Inspect Headers
                  </button>
                </div>
              </div>

              {/* YouTube */}
              <div className="bg-neutral-900/60 border border-neutral-800 rounded-lg p-5 flex flex-col justify-between hover:border-neutral-700 transition-colors">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-full bg-rose-950/60 border border-rose-500/30 flex items-center justify-center text-rose-400 font-bold text-xs">
                        YT
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-neutral-100">YouTube Video Podcasting</h4>
                        <span className="text-xs text-neutral-500">Auto-Generates Description Chapters</span>
                      </div>
                    </div>
                    <span className="text-xs px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-500/20 font-mono">
                      DRAFT
                    </span>
                  </div>
                  <p className="text-xs text-neutral-400 leading-relaxed">
                    Ready to publish 16:9 studio video canvas with auto-rendered audiogram and synchronized subtitles.
                  </p>
                </div>

                <div className="pt-4 border-t border-neutral-800 flex items-center justify-between text-xs mt-4">
                  <span className="text-neutral-500 font-mono">Video: 1080p MP4 Ready</span>
                  <button
                    onClick={() => alert('Publishing video episode to YouTube channel...')}
                    className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded font-medium"
                  >
                    Publish to YouTube
                  </button>
                </div>
              </div>

              {/* Amazon & Overcast */}
              <div className="bg-neutral-900/60 border border-neutral-800 rounded-lg p-5 flex flex-col justify-between hover:border-neutral-700 transition-colors">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-full bg-amber-950/60 border border-amber-500/30 flex items-center justify-center text-amber-400 font-bold text-xs">
                        AM
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-neutral-100">Amazon Music & Overcast</h4>
                        <span className="text-xs text-neutral-500">Fast RSS 2.0 Ping</span>
                      </div>
                    </div>
                    <span className="text-xs px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-500/20 font-mono">
                      SYNCED
                    </span>
                  </div>
                  <p className="text-xs text-neutral-400 leading-relaxed">
                    Auto-ping enabled for all global podcast aggregators via WebSub protocol.
                  </p>
                </div>

                <div className="pt-4 border-t border-neutral-800 flex items-center justify-between text-xs mt-4">
                  <span className="text-neutral-500 font-mono">WebSub: Active</span>
                  <button
                    onClick={() => alert('Pinged aggregators!')}
                    className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 rounded text-neutral-200 font-medium"
                  >
                    Send WebSub Ping
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: RSS FEED GENERATOR */}
        {activeTab === 'rss' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
              <div>
                <h2 className="text-lg font-bold text-neutral-100">Podcast RSS 2.0 Feed</h2>
                <p className="text-xs text-neutral-400 mt-0.5">
                  Valid XML feed adhering to Apple Podcasts and Spotify namespace specifications.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => copyText('https://feeds.resonatestudio.fm/techfrontier/rss.xml', 'rssurl')}
                  className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-md text-xs font-semibold flex items-center gap-1.5 shadow-sm"
                >
                  {copiedType === 'rssurl' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedType === 'rssurl' ? 'Copied Public URL' : 'Copy Feed URL'}
                </button>
              </div>
            </div>

            <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-lg flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <Rss className="w-4 h-4 text-amber-500" />
                <span className="text-neutral-400">Public RSS Endpoint:</span>
                <span className="text-neutral-200 font-mono select-all">
                  https://feeds.resonatestudio.fm/techfrontier/rss.xml
                </span>
              </div>
              <span className="text-emerald-400 font-mono text-[11px]">Valid RSS 2.0</span>
            </div>

            <div className="bg-neutral-900/60 border border-neutral-800 rounded-lg p-4">
              <div className="flex justify-between items-center mb-2">
                <span className="text-xs font-semibold text-neutral-400 font-mono">XML Feed Source</span>
                <button
                  onClick={() => copyText(rssXml, 'rssxml')}
                  className="text-xs text-neutral-400 hover:text-white flex items-center gap-1"
                >
                  {copiedType === 'rssxml' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  Copy Raw XML
                </button>
              </div>
              <pre className="bg-neutral-950 p-4 rounded border border-neutral-800 text-[11px] font-mono text-emerald-400/90 overflow-x-auto leading-relaxed max-h-96">
                {rssXml}
              </pre>
            </div>
          </div>
        )}

        {/* TAB 3: EMBEDDABLE WEB PLAYER */}
        {activeTab === 'embed' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
              <div>
                <h2 className="text-lg font-bold text-neutral-100">Interactive Embed Player</h2>
                <p className="text-xs text-neutral-400 mt-0.5">
                  Responsive player ready to embed into Substack, WordPress, Ghost, or custom websites.
                </p>
              </div>

              <button
                onClick={() => copyText(`<iframe src="https://player.resonatestudio.fm/ep/042" width="100%" height="160" frameborder="0" scrolling="no"></iframe>`, 'embedcode')}
                className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-md text-xs font-semibold flex items-center gap-1.5"
              >
                {copiedType === 'embedcode' ? <Check className="w-3.5 h-3.5" /> : <Code className="w-3.5 h-3.5" />}
                {copiedType === 'embedcode' ? 'Copied iFrame Code' : 'Copy Embed Code'}
              </button>
            </div>

            {/* Interactive Player Preview Card */}
            <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-6 shadow-2xl max-w-2xl mx-auto">
              <div className="flex gap-4 items-center">
                {/* Podcast Cover Graphic */}
                <div className="w-24 h-24 rounded-lg bg-gradient-to-br from-blue-600 to-indigo-950 flex flex-col items-center justify-center text-white shrink-0 shadow-lg border border-blue-400/20">
                  <Radio className="w-6 h-6 mb-1 text-blue-200" />
                  <span className="font-bold text-[10px] tracking-tight">THE TECH</span>
                  <span className="font-mono text-[9px] text-blue-300">FRONTIER</span>
                </div>

                {/* Details & Controls */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] text-amber-400 font-mono font-semibold">
                      EPISODE 42
                    </span>
                    <span className="text-[11px] text-neutral-500 font-mono">1m 38s</span>
                  </div>

                  <h3 className="text-sm font-bold text-neutral-100 truncate mt-0.5">
                    {episode.title}
                  </h3>
                  <p className="text-xs text-neutral-400 truncate mt-0.5">
                    Marcus Vance & Sarah Chen
                  </p>

                  {/* Scrubber Bar */}
                  <div className="mt-3">
                    <div
                      className="w-full h-1.5 bg-neutral-800 rounded-full cursor-pointer relative"
                      onClick={(e) => {
                        const rect = e.currentTarget.getBoundingClientRect();
                        const pct = ((e.clientX - rect.left) / rect.width) * 100;
                        setEmbedProgress(pct);
                      }}
                    >
                      <div
                        className="h-full bg-blue-500 rounded-full"
                        style={{ width: `${embedProgress}%` }}
                      />
                    </div>
                  </div>

                  {/* Buttons */}
                  <div className="flex items-center justify-between mt-3 text-xs">
                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => setEmbedPlaying(!embedPlaying)}
                        className="w-8 h-8 rounded-full bg-blue-500 hover:bg-blue-400 text-white flex items-center justify-center shadow"
                      >
                        {embedPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current translate-x-0.5" />}
                      </button>

                      <button
                        onClick={() => setEmbedProgress(Math.max(0, embedProgress - 10))}
                        className="text-neutral-400 hover:text-white"
                        title="Skip back 15s"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => setEmbedProgress(Math.min(100, embedProgress + 10))}
                        className="text-neutral-400 hover:text-white"
                        title="Skip forward 15s"
                      >
                        <FastForward className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => {
                          const speeds = ['1.0x', '1.25x', '1.5x', '2.0x'];
                          const next = speeds[(speeds.indexOf(embedSpeed) + 1) % speeds.length];
                          setEmbedSpeed(next);
                        }}
                        className="px-2 py-0.5 rounded bg-neutral-800 border border-neutral-700 text-neutral-300 font-mono text-[11px]"
                      >
                        {embedSpeed}
                      </button>

                      <button className="text-neutral-400 hover:text-white">
                        <Share2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: EPISODE WEBPAGE PREVIEW */}
        {activeTab === 'webpage' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
              <div>
                <h2 className="text-lg font-bold text-neutral-100">Public Podcast Webpage</h2>
                <p className="text-xs text-neutral-400 mt-0.5">
                  Hosted landing page for this episode with player, chapters, and full transcript.
                </p>
              </div>

              <a
                href="https://resonate.studio/show/the-tech-frontier/ep-042"
                target="_blank"
                rel="noreferrer"
                className="px-3.5 py-1.5 bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-white rounded-md text-xs font-semibold flex items-center gap-1.5"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                Open Live Webpage
              </a>
            </div>

            {/* Mock Webpage Frame */}
            <div className="bg-neutral-950 border border-neutral-800 rounded-xl overflow-hidden shadow-2xl">
              {/* Browser chrome simulation */}
              <div className="h-8 bg-neutral-900 border-b border-neutral-800 px-3 flex items-center gap-2">
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500/80" />
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
                </div>
                <div className="flex-1 text-center font-mono text-[11px] text-neutral-500">
                  resonate.studio/ep/042-autonomous-media
                </div>
              </div>

              {/* Page body */}
              <div className="p-8 max-w-2xl mx-auto space-y-6">
                <div>
                  <span className="text-xs font-mono text-blue-400 font-semibold uppercase tracking-wider">
                    Season 3 · Episode 42
                  </span>
                  <h1 className="text-2xl font-bold text-neutral-100 mt-1">
                    {episode.title}
                  </h1>
                  <div className="flex items-center gap-3 text-xs text-neutral-400 mt-2">
                    <span>Host: Marcus Vance</span>
                    <span>·</span>
                    <span>Guest: Sarah Chen</span>
                    <span>·</span>
                    <span>March 2026</span>
                  </div>
                </div>

                {/* Listen Buttons */}
                <div className="flex flex-wrap gap-2 pt-2">
                  <button className="px-3 py-1.5 rounded-full bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-xs font-medium text-emerald-400 flex items-center gap-1.5">
                    Listen on Spotify
                  </button>
                  <button className="px-3 py-1.5 rounded-full bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-xs font-medium text-purple-400 flex items-center gap-1.5">
                    Apple Podcasts
                  </button>
                  <button className="px-3 py-1.5 rounded-full bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-xs font-medium text-rose-400 flex items-center gap-1.5">
                    Watch on YouTube
                  </button>
                </div>

                {/* Show Notes */}
                <div className="pt-4 border-t border-neutral-800/80">
                  <h3 className="text-sm font-semibold text-neutral-200 mb-2">About This Episode</h3>
                  <p className="text-xs text-neutral-400 leading-relaxed">
                    {episode.showNotes.summary}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
