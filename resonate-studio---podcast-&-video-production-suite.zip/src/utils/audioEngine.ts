/**
 * Audio Engine utilizing Web Audio API for:
 * 1. Live Mic VU Meter & Peak Detection
 * 2. Instant Zero-Latency Synthesized Soundboard FX
 * 3. Timeline Playback Synthesizer with speech frequency simulation
 */

class AudioEngine {
  private ctx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private micSource: MediaStreamAudioSourceNode | null = null;
  private isSynthesizingSpeech = false;
  private speechOscillator: OscillatorNode | null = null;
  private speechGain: GainNode | null = null;

  private initContext(): AudioContext {
    if (!this.ctx || this.ctx.state === 'closed') {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  /** Connect microphone stream to AnalyserNode for live VU metering */
  public setupMicMeter(stream: MediaStream, onVolume: (rms: number, peak: boolean) => void): () => void {
    const ctx = this.initContext();
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 256;
    analyser.smoothingTimeConstant = 0.8;

    const source = ctx.createMediaStreamSource(stream);
    source.connect(analyser);

    this.analyser = analyser;
    this.micSource = source;

    const dataArray = new Uint8Array(analyser.frequencyBinCount);
    let animationId: number;

    const checkVolume = () => {
      if (!this.analyser) return;
      this.analyser.getByteFrequencyData(dataArray);

      let sum = 0;
      let maxVal = 0;
      for (let i = 0; i < dataArray.length; i++) {
        sum += dataArray[i];
        if (dataArray[i] > maxVal) maxVal = dataArray[i];
      }

      const avg = sum / dataArray.length;
      const normalized = Math.min(100, Math.round((avg / 128) * 100));
      const isPeak = maxVal > 240;

      onVolume(normalized, isPeak);
      animationId = requestAnimationFrame(checkVolume);
    };

    checkVolume();

    return () => {
      cancelAnimationFrame(animationId);
      source.disconnect();
    };
  }

  /** Plays synthesized soundboard sound with zero latency */
  public playSoundEffect(type: 'airhorn' | 'applause' | 'drum' | 'whoosh' | 'scratch' | 'chime' | 'sting') {
    const ctx = this.initContext();
    const now = ctx.currentTime;

    switch (type) {
      case 'airhorn': {
        // Classic triple tone airhorn
        const freqs = [311.13, 370.0, 466.16];
        freqs.forEach(freq => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sawtooth';
          osc.frequency.setValueAtTime(freq, now);
          osc.frequency.exponentialRampToValueAtTime(freq * 0.96, now + 0.35);

          gain.gain.setValueAtTime(0.18, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.38);

          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now);
          osc.stop(now + 0.4);
        });
        break;
      }

      case 'applause': {
        // Filtered crowd burst noise
        const bufferSize = ctx.sampleRate * 1.5;
        const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
          data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (ctx.sampleRate * 0.9));
        }

        const noise = ctx.createBufferSource();
        noise.buffer = buffer;

        const filter = ctx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(1200, now);
        filter.Q.setValueAtTime(1.5, now);

        const gain = ctx.createGain();
        gain.gain.setValueAtTime(0.35, now);
        gain.gain.linearRampToValueAtTime(0.01, now + 1.4);

        noise.connect(filter);
        filter.connect(gain);
        gain.connect(ctx.destination);

        noise.start(now);
        break;
      }

      case 'drum': {
        // Punchy kick + clap
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.frequency.setValueAtTime(140, now);
        osc.frequency.exponentialRampToValueAtTime(42, now + 0.2);

        gain.gain.setValueAtTime(0.5, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.26);
        break;
      }

      case 'whoosh': {
        // White noise sweep
        const bufferSize = ctx.sampleRate * 0.5;
        const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
          data[i] = Math.random() * 2 - 1;
        }

        const noise = ctx.createBufferSource();
        noise.buffer = buffer;

        const filter = ctx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(300, now);
        filter.frequency.exponentialRampToValueAtTime(3500, now + 0.25);
        filter.frequency.exponentialRampToValueAtTime(400, now + 0.5);

        const gain = ctx.createGain();
        gain.gain.setValueAtTime(0.01, now);
        gain.gain.linearRampToValueAtTime(0.25, now + 0.2);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);

        noise.connect(filter);
        filter.connect(gain);
        gain.connect(ctx.destination);

        noise.start(now);
        break;
      }

      case 'chime': {
        // Pleasant bell chime
        const chimeFreqs = [523.25, 659.25, 783.99, 1046.5];
        chimeFreqs.forEach((freq, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, now + idx * 0.06);

          gain.gain.setValueAtTime(0.15, now + idx * 0.06);
          gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.06 + 0.7);

          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now + idx * 0.06);
          osc.stop(now + idx * 0.06 + 0.75);
        });
        break;
      }

      case 'scratch': {
        // Vinyl scratch sweep
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(180, now);
        osc.frequency.linearRampToValueAtTime(800, now + 0.1);
        osc.frequency.linearRampToValueAtTime(120, now + 0.25);

        gain.gain.setValueAtTime(0.3, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.28);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.3);
        break;
      }

      case 'sting': {
        // 8-bit upbeat victory sting
        const notes = [440, 554.37, 659.25, 880];
        notes.forEach((freq, i) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'square';
          osc.frequency.setValueAtTime(freq, now + i * 0.08);

          gain.gain.setValueAtTime(0.12, now + i * 0.08);
          gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.08 + 0.2);

          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now + i * 0.08);
          osc.stop(now + i * 0.08 + 0.22);
        });
        break;
      }
    }
  }

  /** Start subtle acoustic harmonic tone when timeline is playing, simulating podcast voice audio */
  public startTimelineTone(speakerIsHost: boolean = true) {
    if (this.isSynthesizingSpeech) return;
    try {
      const ctx = this.initContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      // Marcus Vance lower pitch (~130Hz), Sarah Chen higher pitch (~220Hz)
      const baseFreq = speakerIsHost ? 135 : 215;
      osc.frequency.setValueAtTime(baseFreq, ctx.currentTime);

      gain.gain.setValueAtTime(0.03, ctx.currentTime);

      // Low pass filter to make it sound warm and conversational
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(800, ctx.currentTime);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      this.speechOscillator = osc;
      this.speechGain = gain;
      this.isSynthesizingSpeech = true;
    } catch (e) {
      // Audio might be blocked if user hasn't interacted yet
    }
  }

  public stopTimelineTone() {
    if (!this.isSynthesizingSpeech) return;
    try {
      if (this.speechGain && this.ctx) {
        this.speechGain.gain.setValueAtTime(0, this.ctx.currentTime);
      }
      if (this.speechOscillator) {
        this.speechOscillator.stop();
        this.speechOscillator.disconnect();
      }
    } catch {
      // ignore
    }
    this.speechOscillator = null;
    this.speechGain = null;
    this.isSynthesizingSpeech = false;
  }
}

export const audioEngine = new AudioEngine();
