import React, { useState, useEffect, useRef } from 'react';
import { 
  Mic, MicOff, Video, VideoOff, Monitor, Radio, Disc, Volume2, 
  Settings, Sparkles, CheckCircle2, AlertCircle, Share2, 
  Layers, Sliders, Play, Square, BookmarkPlus, Zap
} from 'lucide-react';
import { audioEngine } from '../../utils/audioEngine';
import { Episode, Track, TranscriptWord } from '../../types';

interface RecordingStudioProps {
  episode: Episode;
  onFinishRecording: (newTracks: Track[], newWords: TranscriptWord[]) => void;
  onNavigateToEditor: () => void;
}

export const RecordingStudio: React.FC<RecordingStudioProps> = ({
  episode,
  onFinishRecording,
  onNavigateToEditor
}) => {
  // Device & Stream states
  const [micEnabled, setMicEnabled] = useState(true);
  const [videoEnabled, setVideoEnabled] = useState(true);
  const [screenSharing, setScreenSharing] = useState(false);
  const [streamError, setStreamError] = useState<string | null>(null);

  // Metering & Soundboard
  const [hostVolume, setHostVolume] = useState(0);
  const [hostPeak, setHostPeak] = useState(false);
  const [guestVolume, setGuestVolume] = useState(25);
  const [activeSound, setActiveSound] = useState<string | null>(null);

  // Studio Mode & Quality
  const [noiseGate, setNoiseGate] = useState(true);
  const [studioSampleRate, setStudioSampleRate] = useState<'48kHz' | '96kHz'>('48kHz');
  const [layoutMode, setLayoutMode] = useState<'split' | 'pip' | 'active'>('split');

  // Recording State
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [countdown, setCountdown] = useState<number | null>(null);
  const [recordSeconds, setRecordSeconds] = useState(0);
  const [recordedTakes, setRecordedTakes] = useState<{ id: string; time: string; label: string; type: 'good' | 'outtake' }[]>([]);

  // Refs
  const hostVideoRef = useRef<HTMLVideoElement>(null);
  const screenVideoRef = useRef<HTMLVideoElement>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const screenStreamRef = useRef<MediaStream | null>(null);
  const timerIntervalRef = useRef<any>(null);

  // Initialize Host Camera & Mic
  useEffect(() => {
    let cleanupMeter: (() => void) | undefined;

    async function setupDevices() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: {
            echoCancellation: true,
            noiseSuppression: noiseGate,
            autoGainControl: false,
          },
          video: {
            width: { ideal: 1280 },
            height: { ideal: 720 },
            facingMode: 'user'
          }
        });

        mediaStreamRef.current = stream;
        if (hostVideoRef.current) {
          hostVideoRef.current.srcObject = stream;
        }

        cleanupMeter = audioEngine.setupMicMeter(stream, (rms, peak) => {
          setHostVolume(rms);
          setHostPeak(peak);
        });
        setStreamError(null);
      } catch (err: any) {
        console.warn('Camera/Mic permission access notice:', err);
        setStreamError('Studio preview running in virtual broadcast mode (webcam/mic disabled or blocked).');
      }
    }

    setupDevices();

    return () => {
      if (cleanupMeter) cleanupMeter();
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach(t => t.stop());
      }
      if (screenStreamRef.current) {
        screenStreamRef.current.getTracks().forEach(t => t.stop());
      }
    };
  }, [noiseGate]);

  // Simulate remote guest audio meter movement
  useEffect(() => {
    const guestInterval = setInterval(() => {
      if (isRecording) {
        // Natural speech variation
        const randomVol = Math.floor(Math.random() * 45) + 15;
        setGuestVolume(randomVol);
      } else {
        setGuestVolume(Math.floor(Math.random() * 15) + 5);
      }
    }, 180);

    return () => clearInterval(guestInterval);
  }, [isRecording]);

  // Screen share handler
  const handleToggleScreenShare = async () => {
    if (screenSharing) {
      if (screenStreamRef.current) {
        screenStreamRef.current.getTracks().forEach(t => t.stop());
      }
      setScreenSharing(false);
    } else {
      try {
        const screenStream = await navigator.mediaDevices.getDisplayMedia({
          video: true,
          audio: true
        });
        screenStreamRef.current = screenStream;
        if (screenVideoRef.current) {
          screenVideoRef.current.srcObject = screenStream;
        }
        setScreenSharing(true);

        screenStream.getVideoTracks()[0].onended = () => {
          setScreenSharing(false);
        };
      } catch (err) {
        console.log('Screen share cancelled or not allowed');
      }
    }
  };

  // Toggle Mute / Cam
  const handleToggleMic = () => {
    if (mediaStreamRef.current) {
      const audioTrack = mediaStreamRef.current.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        setMicEnabled(audioTrack.enabled);
      }
    } else {
      setMicEnabled(!micEnabled);
    }
  };

  const handleToggleVideo = () => {
    if (mediaStreamRef.current) {
      const videoTrack = mediaStreamRef.current.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled;
        setVideoEnabled(videoTrack.enabled);
      }
    } else {
      setVideoEnabled(!videoEnabled);
    }
  };

  // Recording controls with 3-2-1 countdown
  const startStudioRecording = () => {
    setCountdown(3);
    const countInterval = setInterval(() => {
      setCountdown((prev) => {
        if (prev === null || prev <= 1) {
          clearInterval(countInterval);
          setIsRecording(true);
          setRecordSeconds(0);
          audioEngine.playSoundEffect('sting');
          return null;
        }
        return prev - 1;
      });
    }, 1000);
  };

  // Timer tick
  useEffect(() => {
    if (isRecording && !isPaused) {
      timerIntervalRef.current = setInterval(() => {
        setRecordSeconds(prev => prev + 1);
      }, 1000);
    } else {
      clearInterval(timerIntervalRef.current);
    }
    return () => clearInterval(timerIntervalRef.current);
  }, [isRecording, isPaused]);

  // Finish Recording
  const stopAndCommitRecording = () => {
    setIsRecording(false);
    setIsPaused(false);
    audioEngine.playSoundEffect('chime');

    // Create a new set of sample transcript & track updates
    const newTranscript: TranscriptWord[] = [
      { id: `rec-w-1-${Date.now()}`, word: 'Alright,', start: 0.1, end: 0.5, speaker: 'Marcus Vance (Host)', confidence: 0.99 },
      { id: `rec-w-2-${Date.now()}`, word: 'we', start: 0.5, end: 0.7, speaker: 'Marcus Vance (Host)', confidence: 0.99 },
      { id: `rec-w-3-${Date.now()}`, word: 'just', start: 0.7, end: 0.9, speaker: 'Marcus Vance (Host)', confidence: 0.98 },
      { id: `rec-w-4-${Date.now()}`, word: 'wrapped', start: 0.9, end: 1.3, speaker: 'Marcus Vance (Host)', confidence: 0.99 },
      { id: `rec-w-5-${Date.now()}`, word: 'our', start: 1.3, end: 1.5, speaker: 'Marcus Vance (Host)', confidence: 0.99 },
      { id: `rec-w-6-${Date.now()}`, word: 'live', start: 1.5, end: 1.8, speaker: 'Marcus Vance (Host)', confidence: 0.99 },
      { id: `rec-w-7-${Date.now()}`, word: 'take.', start: 1.8, end: 2.2, speaker: 'Marcus Vance (Host)', confidence: 0.99 },
      { id: `rec-w-8-${Date.now()}`, word: 'Um,', start: 2.3, end: 2.6, speaker: 'Marcus Vance (Host)', isFiller: true, confidence: 0.92 },
      { id: `rec-w-9-${Date.now()}`, word: 'the', start: 2.6, end: 2.8, speaker: 'Marcus Vance (Host)', confidence: 0.98 },
      { id: `rec-w-10-${Date.now()}`, word: 'audio', start: 2.8, end: 3.2, speaker: 'Marcus Vance (Host)', confidence: 0.99 },
      { id: `rec-w-11-${Date.now()}`, word: 'fidelity', start: 3.2, end: 3.7, speaker: 'Marcus Vance (Host)', confidence: 0.97 },
      { id: `rec-w-12-${Date.now()}`, word: 'on', start: 3.7, end: 3.9, speaker: 'Marcus Vance (Host)', confidence: 0.99 },
      { id: `rec-w-13-${Date.now()}`, word: 'the', start: 3.9, end: 4.1, speaker: 'Marcus Vance (Host)', confidence: 0.99 },
      { id: `rec-w-14-${Date.now()}`, word: 'local', start: 4.1, end: 4.4, speaker: 'Marcus Vance (Host)', confidence: 0.99 },
      { id: `rec-w-15-${Date.now()}`, word: 'buffer', start: 4.4, end: 4.8, speaker: 'Marcus Vance (Host)', confidence: 0.99 },
      { id: `rec-w-16-${Date.now()}`, word: 'is', start: 4.8, end: 5.0, speaker: 'Marcus Vance (Host)', confidence: 0.99 },
      { id: `rec-w-17-${Date.now()}`, word: 'flawless.', start: 5.0, end: 5.5, speaker: 'Marcus Vance (Host)', confidence: 0.99 },
      ...episode.transcript
    ];

    onFinishRecording(episode.tracks, newTranscript);
    onNavigateToEditor();
  };

  const addTakeMarker = (type: 'good' | 'outtake') => {
    const mins = Math.floor(recordSeconds / 60).toString().padStart(2, '0');
    const secs = (recordSeconds % 60).toString().padStart(2, '0');
    const newTake = {
      id: `take-${Date.now()}`,
      time: `${mins}:${secs}`,
      label: type === 'good' ? 'Hero Soundbite' : 'Cut Outtake',
      type
    };
    setRecordedTakes(prev => [newTake, ...prev]);
    audioEngine.playSoundEffect(type === 'good' ? 'chime' : 'scratch');
  };

  const triggerSound = (name: 'airhorn' | 'applause' | 'drum' | 'whoosh' | 'scratch' | 'chime') => {
    setActiveSound(name);
    audioEngine.playSoundEffect(name);
    setTimeout(() => setActiveSound(null), 400);
  };

  const formatTimer = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60).toString().padStart(2, '0');
    const secs = (totalSeconds % 60).toString().padStart(2, '0');
    return `${mins}:${secs}`;
  };

  return (
    <div className="h-full flex flex-col bg-neutral-950 text-neutral-100 overflow-hidden">
      {/* Studio Header Bar */}
      <div className="h-14 border-b border-neutral-800/80 px-6 flex items-center justify-between bg-neutral-900/60 backdrop-blur-sm shrink-0">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="font-semibold text-sm tracking-tight text-neutral-100">Live Studio Room</span>
          </div>
          <span className="text-neutral-600">/</span>
          <span className="text-xs text-neutral-400 font-mono">Room ID: res-studio-42-nyc</span>
          <span className="text-neutral-600">/</span>
          <span className="text-xs text-neutral-400">
            Local Tracks: <span className="text-emerald-400 font-mono">48kHz / 24-bit PCM</span>
          </span>
        </div>

        <div className="flex items-center gap-3">
          {/* Layout controls */}
          <div className="flex items-center bg-neutral-900 border border-neutral-800 rounded-md p-0.5 text-xs">
            <button
              onClick={() => setLayoutMode('split')}
              className={`px-2.5 py-1 rounded transition-colors ${layoutMode === 'split' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400 hover:text-neutral-200'}`}
            >
              Split View
            </button>
            <button
              onClick={() => setLayoutMode('pip')}
              className={`px-2.5 py-1 rounded transition-colors ${layoutMode === 'pip' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400 hover:text-neutral-200'}`}
            >
              Host PIP
            </button>
          </div>

          {/* Noise Gate & Studio Settings */}
          <button
            onClick={() => setNoiseGate(!noiseGate)}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-md border transition-colors ${noiseGate ? 'border-indigo-500/40 bg-indigo-950/40 text-indigo-300' : 'border-neutral-800 text-neutral-400 hover:border-neutral-700'}`}
            title="AI Studio Noise Gate"
          >
            <Sparkles className="w-3.5 h-3.5" />
            Studio Noise Gate: {noiseGate ? 'ON' : 'OFF'}
          </button>
        </div>
      </div>

      {/* Main Studio Canvas & Sidebars */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Video Stage */}
        <div className="flex-1 flex flex-col p-4 overflow-y-auto">
          {streamError && (
            <div className="mb-3 px-3 py-2 bg-neutral-900/90 border border-amber-500/30 rounded text-xs text-amber-300 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-amber-400" />
              <span>{streamError}</span>
            </div>
          )}

          {/* Video Grid */}
          <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4 min-h-[380px]">
            {/* Host Screen (Marcus Vance) */}
            <div className="relative bg-neutral-900 rounded-lg border border-neutral-800/80 overflow-hidden flex flex-col shadow-inner">
              <div className="absolute top-3 left-3 z-10 flex items-center gap-2">
                <span className="bg-neutral-950/80 backdrop-blur-md px-2.5 py-1 rounded text-xs font-medium text-blue-300 border border-blue-500/20">
                  Host: Marcus Vance (You)
                </span>
                <span className="bg-emerald-950/80 backdrop-blur-md text-emerald-400 text-xs px-2 py-0.5 rounded border border-emerald-500/20 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                  Local 4K Record
                </span>
              </div>

              {/* Host Video Stream */}
              <div className="flex-1 w-full h-full bg-neutral-950 flex items-center justify-center relative overflow-hidden">
                <video
                  ref={hostVideoRef}
                  autoPlay
                  playsInline
                  muted
                  className={`w-full h-full object-cover transition-opacity ${videoEnabled ? 'opacity-100' : 'opacity-0'}`}
                />

                {!videoEnabled && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center bg-neutral-950">
                    <div className="w-20 h-20 rounded-full bg-blue-900/40 border border-blue-500/30 flex items-center justify-center text-blue-300 text-xl font-bold mb-2">
                      MV
                    </div>
                    <span className="text-xs text-neutral-400">Camera Paused</span>
                  </div>
                )}

                {/* Host Live VU Meter Overlay */}
                <div className="absolute bottom-3 left-3 right-3 z-10 flex items-center justify-between bg-neutral-950/80 backdrop-blur-md px-3 py-1.5 rounded border border-neutral-800/80">
                  <div className="flex items-center gap-2">
                    <Mic className={`w-3.5 h-3.5 ${micEnabled ? 'text-blue-400' : 'text-rose-400'}`} />
                    <span className="text-xs text-neutral-300 font-mono">Shure SM7B (USB)</span>
                  </div>

                  {/* VU Meter Bars */}
                  <div className="flex items-center gap-1 w-32 h-2.5 bg-neutral-900 rounded overflow-hidden px-0.5">
                    <div
                      className={`h-1.5 rounded-sm transition-all duration-75 ${hostPeak ? 'bg-rose-500' : hostVolume > 60 ? 'bg-amber-400' : 'bg-emerald-400'}`}
                      style={{ width: `${Math.max(4, Math.min(100, hostVolume))}%` }}
                    />
                  </div>
                  <span className={`text-[10px] font-mono ${hostPeak ? 'text-rose-400' : 'text-neutral-400'}`}>
                    {hostPeak ? 'CLIP!' : `${Math.round(hostVolume)} dB`}
                  </span>
                </div>
              </div>
            </div>

            {/* Guest Screen (Sarah Chen) */}
            <div className="relative bg-neutral-900 rounded-lg border border-neutral-800/80 overflow-hidden flex flex-col shadow-inner">
              <div className="absolute top-3 left-3 z-10 flex items-center gap-2">
                <span className="bg-neutral-950/80 backdrop-blur-md px-2.5 py-1 rounded text-xs font-medium text-emerald-300 border border-emerald-500/20">
                  Guest: Sarah Chen (Remote)
                </span>
                <span className="bg-emerald-950/80 backdrop-blur-md text-emerald-400 text-xs px-2 py-0.5 rounded border border-emerald-500/20 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                  Local WAV Sync
                </span>
              </div>

              {/* Guest Video Placeholder / Stream */}
              <div className="flex-1 w-full h-full bg-neutral-950 flex flex-col items-center justify-center relative overflow-hidden">
                <div className="w-24 h-24 rounded-full bg-emerald-950/60 border border-emerald-500/30 flex items-center justify-center text-emerald-300 text-2xl font-bold mb-3 shadow-lg">
                  SC
                </div>
                <span className="text-sm font-medium text-neutral-200">Sarah Chen</span>
                <span className="text-xs text-neutral-400 mt-1">Stanford AI Lab / Founder</span>

                {/* Animated speech wave circles around guest avatar */}
                {isRecording && guestVolume > 20 && (
                  <div className="absolute w-36 h-36 rounded-full border border-emerald-500/30 animate-ping pointer-events-none" />
                )}

                {/* Guest VU Meter Overlay */}
                <div className="absolute bottom-3 left-3 right-3 z-10 flex items-center justify-between bg-neutral-950/80 backdrop-blur-md px-3 py-1.5 rounded border border-neutral-800/80">
                  <div className="flex items-center gap-2">
                    <Mic className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-xs text-neutral-300 font-mono">Rode PodMic (Local Track)</span>
                  </div>

                  {/* VU Meter Bars */}
                  <div className="flex items-center gap-1 w-32 h-2.5 bg-neutral-900 rounded overflow-hidden px-0.5">
                    <div
                      className="h-1.5 rounded-sm bg-emerald-400 transition-all duration-100"
                      style={{ width: `${Math.max(4, Math.min(100, guestVolume))}%` }}
                    />
                  </div>
                  <span className="text-[10px] font-mono text-neutral-400">
                    {Math.round(guestVolume)} dB
                  </span>
                </div>
              </div>
            </div>

            {/* Screen Share Slot if active */}
            {screenSharing && (
              <div className="md:col-span-2 relative bg-neutral-900 rounded-lg border border-indigo-500/40 overflow-hidden flex flex-col h-64">
                <div className="absolute top-3 left-3 z-10 bg-indigo-950/90 text-indigo-300 text-xs px-2.5 py-1 rounded border border-indigo-500/30 flex items-center gap-1.5">
                  <Monitor className="w-3.5 h-3.5" />
                  Screen Share Track (Active)
                </div>
                <video
                  ref={screenVideoRef}
                  autoPlay
                  playsInline
                  className="w-full h-full object-contain bg-black"
                />
              </div>
            )}
          </div>

          {/* Countdown Overlay */}
          {countdown !== null && (
            <div className="absolute inset-0 bg-neutral-950/90 backdrop-blur-md z-50 flex flex-col items-center justify-center animate-in fade-in">
              <span className="text-8xl font-black text-amber-400 font-mono tracking-tighter animate-bounce">
                {countdown}
              </span>
              <span className="text-sm font-medium text-neutral-400 mt-4 tracking-wide uppercase">
                Preparing Local Recording Buffers...
              </span>
            </div>
          )}

          {/* Broadcast Bottom Action Bar */}
          <div className="mt-4 bg-neutral-900 border border-neutral-800 rounded-lg px-6 py-3.5 flex items-center justify-between shrink-0 shadow-lg">
            {/* Left Controls: Mic, Video, Screen */}
            <div className="flex items-center gap-2">
              <button
                onClick={handleToggleMic}
                className={`p-2.5 rounded-md border text-xs font-medium flex items-center gap-2 transition-colors ${micEnabled ? 'bg-neutral-800 border-neutral-700 text-neutral-200 hover:bg-neutral-700' : 'bg-rose-950/60 border-rose-600/50 text-rose-300'}`}
                title={micEnabled ? 'Mute Microphone' : 'Unmute Microphone'}
              >
                {micEnabled ? <Mic className="w-4 h-4 text-emerald-400" /> : <MicOff className="w-4 h-4 text-rose-400" />}
                <span className="hidden sm:inline">{micEnabled ? 'Mute' : 'Unmuted'}</span>
              </button>

              <button
                onClick={handleToggleVideo}
                className={`p-2.5 rounded-md border text-xs font-medium flex items-center gap-2 transition-colors ${videoEnabled ? 'bg-neutral-800 border-neutral-700 text-neutral-200 hover:bg-neutral-700' : 'bg-rose-950/60 border-rose-600/50 text-rose-300'}`}
                title={videoEnabled ? 'Stop Video' : 'Start Video'}
              >
                {videoEnabled ? <Video className="w-4 h-4 text-blue-400" /> : <VideoOff className="w-4 h-4 text-rose-400" />}
                <span className="hidden sm:inline">{videoEnabled ? 'Stop Cam' : 'Start Cam'}</span>
              </button>

              <button
                onClick={handleToggleScreenShare}
                className={`p-2.5 rounded-md border text-xs font-medium flex items-center gap-2 transition-colors ${screenSharing ? 'bg-indigo-950/60 border-indigo-500/50 text-indigo-300' : 'bg-neutral-800 border-neutral-700 text-neutral-200 hover:bg-neutral-700'}`}
              >
                <Monitor className="w-4 h-4 text-indigo-400" />
                <span className="hidden sm:inline">{screenSharing ? 'Stop Screen' : 'Share Screen'}</span>
              </button>
            </div>

            {/* Center Record Button & Timer */}
            <div className="flex items-center gap-4">
              {isRecording ? (
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2 bg-rose-950/80 border border-rose-500/40 px-3 py-1.5 rounded-md">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
                    <span className="text-rose-200 font-mono font-bold text-sm">
                      REC {formatTimer(recordSeconds)}
                    </span>
                  </div>

                  <button
                    onClick={() => addTakeMarker('good')}
                    className="px-3 py-1.5 rounded-md bg-neutral-800 border border-neutral-700 text-emerald-400 text-xs font-medium hover:bg-neutral-700 flex items-center gap-1.5"
                    title="Mark Good Take (creates chapter marker)"
                  >
                    <BookmarkPlus className="w-3.5 h-3.5" />
                    Mark Take
                  </button>

                  <button
                    onClick={stopAndCommitRecording}
                    className="px-4 py-2 rounded-md bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold flex items-center gap-2 shadow-md transition-colors"
                  >
                    <Square className="w-3.5 h-3.5 fill-current" />
                    Finish & Edit
                  </button>
                </div>
              ) : (
                <button
                  onClick={startStudioRecording}
                  className="px-6 py-2.5 rounded-md bg-rose-600 hover:bg-rose-500 text-white text-sm font-semibold flex items-center gap-2.5 shadow-lg shadow-rose-950/40 hover:scale-[1.02] transition-all"
                >
                  <Disc className="w-4 h-4 animate-spin" />
                  Start Recording
                </button>
              )}
            </div>

            {/* Right: Guest Invite Link */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  navigator.clipboard?.writeText('https://resonate.studio/room/res-studio-42-nyc');
                  alert('Guest Studio Invite Link copied to clipboard!');
                }}
                className="px-3 py-2 bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 rounded-md text-xs text-neutral-200 font-medium flex items-center gap-1.5 transition-colors"
              >
                <Share2 className="w-3.5 h-3.5 text-neutral-400" />
                Invite Guest
              </button>
            </div>
          </div>
        </div>

        {/* Right Studio Tools Sidebar */}
        <div className="w-80 border-l border-neutral-800/80 bg-neutral-900/40 p-4 flex flex-col gap-5 overflow-y-auto shrink-0">
          {/* Soundboard Panel */}
          <div>
            <div className="flex items-center justify-between mb-2.5">
              <div className="flex items-center gap-1.5">
                <Volume2 className="w-4 h-4 text-amber-400" />
                <h3 className="text-xs font-semibold uppercase tracking-wider text-neutral-300">Live Soundboard</h3>
              </div>
              <span className="text-[11px] text-neutral-500 font-mono">0ms latency</span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'airhorn', label: 'Airhorn', desc: 'Hype intro' },
                { id: 'applause', label: 'Applause', desc: 'Crowd cheer' },
                { id: 'drum', label: 'Drum Hit', desc: 'Rimshot & kick' },
                { id: 'whoosh', label: 'Whoosh', desc: 'Topic sweep' },
                { id: 'scratch', label: 'Scratch', desc: 'Record break' },
                { id: 'chime', label: 'Chime Bell', desc: 'Sponsor bell' }
              ].map(item => (
                <button
                  key={item.id}
                  onClick={() => triggerSound(item.id as any)}
                  className={`p-2.5 rounded border text-left transition-all ${activeSound === item.id ? 'bg-amber-500/20 border-amber-500 text-amber-300 scale-95' : 'bg-neutral-900 border-neutral-800 text-neutral-300 hover:border-neutral-700 hover:bg-neutral-800/80'}`}
                >
                  <div className="text-xs font-medium">{item.label}</div>
                  <div className="text-[10px] text-neutral-500">{item.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Riverside-Style Local Tracks Sync Monitor */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-neutral-300">Track Upload Status</h3>
              <span className="text-[11px] text-emerald-400 font-mono">Lossless WAV</span>
            </div>
            <div className="space-y-2.5 bg-neutral-900/80 p-3 rounded border border-neutral-800 text-xs">
              <div>
                <div className="flex justify-between text-neutral-300 mb-1">
                  <span>Host (You)</span>
                  <span className="font-mono text-emerald-400">100% Synced</span>
                </div>
                <div className="w-full h-1.5 bg-neutral-800 rounded-full overflow-hidden">
                  <div className="w-full h-full bg-blue-500 rounded-full" />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-neutral-300 mb-1">
                  <span>Sarah Chen (Guest)</span>
                  <span className="font-mono text-emerald-400">100% Synced</span>
                </div>
                <div className="w-full h-1.5 bg-neutral-800 rounded-full overflow-hidden">
                  <div className="w-full h-full bg-emerald-500 rounded-full" />
                </div>
              </div>

              <div className="text-[11px] text-neutral-500 pt-1 border-t border-neutral-800/80">
                Audio is recorded uncompressed onto client memory, preventing network stutter.
              </div>
            </div>
          </div>

          {/* Session Takes & Markers */}
          <div className="flex-1 flex flex-col">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-neutral-300 mb-2">Live Takes & Markers</h3>
            <div className="flex-1 bg-neutral-900/60 rounded border border-neutral-800 p-2.5 overflow-y-auto space-y-2 text-xs">
              {recordedTakes.length === 0 ? (
                <div className="text-neutral-500 text-center py-6">
                  No take markers yet. Click "Mark Take" while recording to flag highlights.
                </div>
              ) : (
                recordedTakes.map(take => (
                  <div
                    key={take.id}
                    className="flex items-center justify-between p-2 rounded bg-neutral-800/60 border border-neutral-700/50"
                  >
                    <div className="flex items-center gap-2">
                      <span className={`w-2 h-2 rounded-full ${take.type === 'good' ? 'bg-emerald-400' : 'bg-amber-400'}`} />
                      <span className="text-neutral-200">{take.label}</span>
                    </div>
                    <span className="text-neutral-400 font-mono text-[11px]">{take.time}</span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
