export type TabType = 'studio' | 'editor' | 'transcription' | 'distribution' | 'monetization';

export interface TranscriptWord {
  id: string;
  word: string;
  start: number; // in seconds
  end: number;   // in seconds
  speaker: string;
  isFiller?: boolean;
  isDeleted?: boolean;
  confidence: number;
}

export interface Track {
  id: string;
  name: string;
  type: 'host' | 'guest' | 'screen' | 'music' | 'sfx';
  volume: number; // 0 to 1
  muted: boolean;
  solo: boolean;
  color: string;
  peaks: number[]; // 0 to 1 waveform bars
}

export interface Chapter {
  id: string;
  title: string;
  timestamp: string; // "00:00"
  seconds: number;
  description: string;
}

export interface AdMarker {
  id: string;
  type: 'pre-roll' | 'mid-roll' | 'post-roll';
  timestamp: string;
  seconds: number;
  durationSec: number;
  sponsorName: string;
  cpm: number;
  script: string;
  promoCode: string;
  status: 'scheduled' | 'active' | 'completed';
}

export interface VideoClip {
  id: string;
  title: string;
  startTime: number;
  endTime: number;
  aspectRatio: '9:16' | '16:9' | '1:1';
  hookText: string;
  viralScore: number;
  captionStyle: 'karaoke' | 'bouncy' | 'minimal' | 'boxed';
  reason?: string;
}

export interface ShowNotes {
  summary: string;
  keyTakeaways: string[];
  memorableQuotes: string[];
  resources: string[];
}

export interface DistributionStatus {
  spotify: 'synced' | 'pending' | 'draft';
  apple: 'synced' | 'pending' | 'draft';
  youtube: 'synced' | 'pending' | 'draft';
  amazon: 'synced' | 'pending' | 'draft';
  rssUrl: string;
}

export interface MonetizationMetrics {
  monthlyDownloads: number;
  activeSponsorsCount: number;
  averageCpm: number;
  projectedRevenue: number;
  subscriberCount: number;
  subscriberRevenue: number;
}

export interface Episode {
  id: string;
  title: string;
  subtitle: string;
  episodeNumber: number;
  season: number;
  duration: number; // in seconds
  status: 'recording' | 'editing' | 'ready' | 'published';
  recordedAt: string;
  coverArt: string;
  tracks: Track[];
  transcript: TranscriptWord[];
  chapters: Chapter[];
  ads: AdMarker[];
  clips: VideoClip[];
  showNotes: ShowNotes;
  distribution: DistributionStatus;
  monetization: MonetizationMetrics;
}
