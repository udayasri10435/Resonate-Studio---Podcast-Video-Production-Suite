import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());

// Initialize Gemini SDK if API key is provided
let aiClient: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  aiClient = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
}

// AI Endpoint for Studio Features (Show Notes, Chapters, Shorts Highlight, Sponsor Pitch)
app.post('/api/ai/generate', async (req: Request, res: Response) => {
  const { task, transcriptText, episodeTitle, context } = req.body;

  if (!aiClient) {
    return res.status(200).json({
      fallback: true,
      message: 'Using built-in intelligent studio templates (Gemini API key not configured).',
      result: getFallbackResult(task, episodeTitle, transcriptText, context)
    });
  }

  try {
    let prompt = '';
    if (task === 'show_notes') {
      prompt = `You are a world-class podcast producer. Generate comprehensive, engaging show notes for the podcast episode titled "${episodeTitle}".
Transcript excerpt:
${transcriptText}

Output a structured JSON response with these exact keys:
{
  "summary": "2-3 paragraphs high-level engaging summary",
  "keyTakeaways": ["insight 1", "insight 2", "insight 3", "insight 4"],
  "memorableQuotes": ["quote 1", "quote 2"],
  "resources": ["resource/tool 1", "resource 2"]
}
Only return valid raw JSON.`;
    } else if (task === 'chapters') {
      prompt = `Analyze this podcast transcript and create 5-8 logical chapter markers with timestamps.
Episode: "${episodeTitle}"
Transcript:
${transcriptText}

Return raw JSON as an array of objects:
[
  { "timestamp": "00:00", "title": "Introduction & Overview", "description": "Quick intro" },
  { "timestamp": "02:15", "title": "Topic Heading", "description": "Key points discussed" }
]
Only return valid raw JSON.`;
    } else if (task === 'viral_shorts') {
      prompt = `Find 3 viral-ready short video clip candidates (30-60s) from this podcast transcript.
Episode: "${episodeTitle}"
Transcript:
${transcriptText}

Return raw JSON as an array of objects:
[
  { "title": "Catchy Hook Title", "startTime": "01:20", "endTime": "01:55", "hookText": "First sentence hook that stops scrollers", "viralScore": 95, "reason": "Why it will perform well on TikTok/Reels" }
]
Only return valid raw JSON.`;
    } else if (task === 'sponsor_pitch') {
      prompt = `Write a compelling, professional sponsorship pitch email for the podcast "${episodeTitle}" targeting a sponsor in the ${context || 'Tech & AI'} space.
Include listenership value, CPM model, and sponsor integration options.
Return JSON with { "subject": "Email Subject", "body": "Full Email Text" }.`;
    } else {
      prompt = `Assist with podcast production for "${episodeTitle}". Task: ${task}. Context: ${transcriptText}`;
    }

    const response = await aiClient.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
    });

    const text = response.text || '';
    let parsed;
    try {
      const cleaned = text.replace(/```json\n?|\n?```/g, '').trim();
      parsed = JSON.parse(cleaned);
    } catch {
      parsed = { rawText: text };
    }

    return res.json({ fallback: false, result: parsed });
  } catch (error: any) {
    console.error('Gemini API error, falling back:', error.message);
    return res.status(200).json({
      fallback: true,
      result: getFallbackResult(task, episodeTitle, transcriptText, context)
    });
  }
});

function getFallbackResult(task: string, title?: string, transcript?: string, context?: string) {
  if (task === 'show_notes') {
    return {
      summary: `In this deep-dive episode of "${title || 'The Tech Frontier'}", we unpack the seismic shifts in intelligent software development, creative tools, and workflow automation. Marcus Vance is joined by Sarah Chen to dissect what truly separates modern creator studios from legacy workstations, why text-based editing is redefining media production, and how creators are scaling distributed audiences with high-fidelity local multi-track pipelines.`,
      keyTakeaways: [
        'Local-first studio recording eliminates compression artifacts and packet loss seen in standard browser calls.',
        'Text-based editing transforms audio cutting from tedious scrubbing into seamless word processing.',
        'Dynamic Ad Insertion (DAI) enables podcasters to monetize back-catalog episodes automatically.',
        'Short-form vertical video extraction is the highest ROI distribution channel for long-form audio.'
      ],
      memorableQuotes: [
        '“If you can edit a Google Doc, you can now produce a broadcast-quality production.”',
        '“The friction between having an idea and shipping a global broadcast has dropped to near zero.”'
      ],
      resources: [
        'Resonate Studio Studio Core (Local Web Audio Pipeline)',
        'Apple Podcasts Specifications 2026',
        'Spotify Video Podcasting SDK'
      ]
    };
  } else if (task === 'chapters') {
    return [
      { timestamp: '00:00', title: 'Cold Open & Welcome', description: 'Studio greeting, episode overview and sponsor shoutout.' },
      { timestamp: '01:14', title: 'Why Traditional Media Editing Fails', description: 'Examining the 5x timeline tax on modern creators.' },
      { timestamp: '03:45', title: 'The Text-Based Revolution', description: 'How editing transcripts directly cuts audio and video waveforms.' },
      { timestamp: '07:20', title: 'Riverside vs Studio Quality Breakdown', description: 'Comparing local-track recording against streaming compression.' },
      { timestamp: '11:05', title: 'Monetization Architecture & Dynamic Ads', description: 'Pre-roll, mid-roll, and subscriber-gated tiers.' },
      { timestamp: '14:30', title: 'Future Predictions & Key Takeaways', description: 'Wrap up, show links, and next week teaser.' }
    ];
  } else if (task === 'viral_shorts') {
    return [
      {
        title: 'Why Editing Video Like a Text Doc Changes Everything',
        startTime: '03:45',
        endTime: '04:25',
        hookText: 'You will never drag an audio playhead again after seeing this.',
        viralScore: 96,
        reason: 'Contrarian workflow revelation with immediate visual "aha!" moment.'
      },
      {
        title: 'The Brutal Truth About Streaming Quality',
        startTime: '07:30',
        endTime: '08:12',
        hookText: 'Stop recording your podcast over Zoom. Here is what your listeners actually hear.',
        viralScore: 92,
        reason: 'Callout hook targeting creators making a common mistake.'
      },
      {
        title: 'How Solo Creators Make $20k/Mo with Dynamic Ads',
        startTime: '11:15',
        endTime: '11:58',
        hookText: 'Most podcasters make $0 on old episodes. Here is how top shows monetize backlogs.',
        viralScore: 89,
        reason: 'Specific revenue numbers create intense curiosity and save-rate.'
      }
    ];
  } else if (task === 'sponsor_pitch') {
    return {
      subject: `Partnership Inquiry: The Tech Frontier Podcast x ${context || 'Your Brand'}`,
      body: `Hi team,

I've been following your recent developments and love the product focus. I host "The Tech Frontier", a weekly video and audio podcast reaching 42,000+ engineers, product creators, and tech founders per episode.

Our listeners are highly engaged builders:
• 42,000+ Average 30-Day Downloads
• 74% Average Episode Completion Rate
• Audience: 68% US/Canada, 72% Senior Engineers & Founders

We are curating select Q4 partners for our Host-Read Mid-Roll slots ($35 CPM). We don't read generic ads; we build genuine product walk-throughs that resonate with technical audiences.

Would you be open to a quick 10-minute chat next Tuesday to see if this aligns with your developer marketing roadmap?

Best regards,
Marcus Vance
Host & Producer, The Tech Frontier`
    };
  }

  return { message: 'Processed successfully' };
}

// Development vs Production serving
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Studio server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
