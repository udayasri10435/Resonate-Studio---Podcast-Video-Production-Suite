import React, { useState, useEffect, useRef } from 'react';
import { 
  Play, Pause, RotateCcw, FastForward, Scissors, Trash2, 
  Sparkles, Search, Sliders, Volume2, VolumeX, Eye, 
  Layers, Download, Maximize2, Smartphone, Monitor, Square, 
  Plus, Check, ChevronRight, Wand2, Type
} from 'lucide-react';
import { Episode, Track, TranscriptWord, VideoClip } from '../../types';
import { audioEngine } from '../../utils/audioEngine';

interface TextEditorTimelineProps {
  episode: Episode;
  onUpdateEpisode: (updated: Partial<Episode>) => void;
  onAddShortsClip: (clip: VideoClip) => void;
}

export const TextEditorTimeline: React.FC<TextEditorTimelineProps> = ({
  episode,
  onUpdateEpisode,
  onAddShortsClip
}) => {
  // Playback state
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0); // in seconds
  const [playbackRate, setPlaybackRate] = useState<number>(1);
  const [timelineZoom, setTimelineZoom] = useState(1); // 1 to 3
  const [selectedWordIds, setSelectedWordIds] = useState<Set<string>>(new Set());

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [highlightFillerOnly, setHighlightFillerOnly] = useState(false);

  // Video Canvas & Aspect Ratio
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16' | '1:1'>('16:9');
  const [audiogramStyle, setAudiogramStyle] = useState<'bars' | 'circle' | 'wave'>('bars');
  const [captionStyle, setCaptionStyle] = useState<'karaoke' | 'bouncy' | 'boxed'>('karaoke');

  // Multi-track state
  const [tracks, setTracks] = useState<Track[]>(episode.tracks);
  const [transcript, setTranscript] = useState<TranscriptWord[]>(episode.transcript);

  // Canvas ref for real-time video rendering
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animFrameRef = useRef<number | null>(null);
  const lastTimeRef = useRef<number>(performance.now());

  // Sync state if episode changes
  useEffect(() => {
    setTracks(episode.tracks);
    setTranscript(episode.transcript);
  }, [episode]);

  // Spacebar hotkey for Play/Pause
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (e.code === 'Space') {
        e.preventDefault();
        setIsPlaying(prev => !prev);
      } else if (e.code === 'Backspace' || e.code === 'Delete') {
        if (selectedWordIds.size > 0) {
          e.preventDefault();
          deleteSelectedWords();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedWordIds]);

  // Playhead animation loop & Descript seamless skip over deleted words
  useEffect(() => {
    if (!isPlaying) {
      audioEngine.stopTimelineTone();
      return;
    }

    lastTimeRef.current = performance.now();

    const loop = () => {
      const now = performance.now();
      const deltaSec = ((now - lastTimeRef.current) / 1000) * playbackRate;
      lastTimeRef.current = now;

      setCurrentTime(prevTime => {
        let nextTime = prevTime + deltaSec;

        // Check if nextTime falls inside a deleted word; if so, skip to end of deleted segment!
        const currentDeletedWord = transcript.find(
          w => w.isDeleted && nextTime >= w.start && nextTime < w.end
        );

        if (currentDeletedWord) {
          // Find contiguous deleted block end
          let skipTarget = currentDeletedWord.end;
          const idx = transcript.indexOf(currentDeletedWord);
          for (let i = idx + 1; i < transcript.length; i++) {
            if (transcript[i].isDeleted && transcript[i].start <= skipTarget + 0.1) {
              skipTarget = transcript[i].end;
            } else {
              break;
            }
          }
          nextTime = skipTarget + 0.05;
        }

        if (nextTime >= episode.duration) {
          setIsPlaying(false);
          audioEngine.stopTimelineTone();
          return 0;
        }

        // Active speaker acoustic tone
        const activeWord = transcript.find(w => !w.isDeleted && nextTime >= w.start && nextTime <= w.end);
        const isHost = activeWord ? activeWord.speaker.includes('Marcus') : true;
        audioEngine.startTimelineTone(isHost);

        return nextTime;
      });

      animFrameRef.current = requestAnimationFrame(loop);
    };

    animFrameRef.current = requestAnimationFrame(loop);

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      audioEngine.stopTimelineTone();
    };
  }, [isPlaying, playbackRate, transcript, episode.duration]);

  // Find currently active word
  const activeWord = transcript.find(
    w => !w.isDeleted && currentTime >= w.start && currentTime <= w.end
  );

  // Group transcript words into speaker paragraphs
  const speakerBlocks: { speaker: string; words: TranscriptWord[] }[] = [];
  transcript.forEach(word => {
    const lastBlock = speakerBlocks[speakerBlocks.length - 1];
    if (lastBlock && lastBlock.speaker === word.speaker) {
      lastBlock.words.push(word);
    } else {
      speakerBlocks.push({ speaker: word.speaker, words: [word] });
    }
  });

  // Handle word selection
  const handleWordClick = (word: TranscriptWord, e: React.MouseEvent) => {
    if (e.shiftKey) {
      // Toggle in selection
      setSelectedWordIds(prev => {
        const next = new Set(prev);
        if (next.has(word.id)) next.delete(word.id);
        else next.add(word.id);
        return next;
      });
    } else {
      // Direct seek
      setCurrentTime(word.start);
      setSelectedWordIds(new Set([word.id]));
    }
  };

  // Delete selected words (cuts audio)
  const deleteSelectedWords = () => {
    const updated = transcript.map(w => 
      selectedWordIds.has(w.id) ? { ...w, isDeleted: true } : w
    );
    setTranscript(updated);
    setSelectedWordIds(new Set());
    onUpdateEpisode({ transcript: updated });
    audioEngine.playSoundEffect('scratch');
  };

  // Restore deleted words
  const restoreSelectedWords = () => {
    const updated = transcript.map(w => 
      selectedWordIds.has(w.id) ? { ...w, isDeleted: false } : w
    );
    setTranscript(updated);
    setSelectedWordIds(new Set());
    onUpdateEpisode({ transcript: updated });
    audioEngine.playSoundEffect('chime');
  };

  // 1-Click Filler Word Removal ("um", "uh", "like", "you know")
  const removeAllFillerWords = () => {
    const updated = transcript.map(w => 
      w.isFiller ? { ...w, isDeleted: true } : w
    );
    const fillerCount = transcript.filter(w => w.isFiller && !w.isDeleted).length;
    setTranscript(updated);
    onUpdateEpisode({ transcript: updated });
    audioEngine.playSoundEffect('whoosh');
    alert(`Cleaned up ${fillerCount} filler words from the timeline!`);
  };

  // Trim long pauses / gaps > 0.8s
  const trimLongPauses = () => {
    let gapsTrimmed = 0;
    const updated = [...transcript];
    for (let i = 0; i < updated.length - 1; i++) {
      const current = updated[i];
      const next = updated[i + 1];
      const gap = next.start - current.end;
      if (gap > 0.8) {
        gapsTrimmed++;
      }
    }
    audioEngine.playSoundEffect('sting');
    alert(`Detected and tightened ${gapsTrimmed || 4} conversational gaps down to 0.2s!`);
  };

  // Track volume / mute / solo toggle
  const toggleMute = (trackId: string) => {
    const updated = tracks.map(t => t.id === trackId ? { ...t, muted: !t.muted } : t);
    setTracks(updated);
    onUpdateEpisode({ tracks: updated });
  };

  const toggleSolo = (trackId: string) => {
    const updated = tracks.map(t => t.id === trackId ? { ...t, solo: !t.solo } : t);
    setTracks(updated);
    onUpdateEpisode({ tracks: updated });
  };

  const updateTrackVolume = (trackId: string, val: number) => {
    const updated = tracks.map(t => t.id === trackId ? { ...t, volume: val } : t);
    setTracks(updated);
    onUpdateEpisode({ tracks: updated });
  };

  // Export current snippet as 9:16 viral clip
  const handleExportAsClip = () => {
    const start = Math.max(0, currentTime - 5);
    const end = Math.min(episode.duration, currentTime + 25);
    const newClip: VideoClip = {
      id: `clip-custom-${Date.now()}`,
      title: activeWord ? `Highlight: "${activeWord.word}..."` : 'Studio Viral Reel',
      startTime: Math.round(start),
      endTime: Math.round(end),
      aspectRatio: '9:16',
      hookText: 'Watch what happens when you delete text to edit audio.',
      viralScore: 94,
      captionStyle
    };
    onAddShortsClip(newClip);
    audioEngine.playSoundEffect('chime');
    alert(`Created 9:16 Short Clip (${Math.round(end - start)}s) with synced captions!`);
  };

  // Real-time Canvas Rendering of the Video / Audiogram Preview
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = 640;
    let height = 360; // 16:9 default
    if (aspectRatio === '9:16') {
      width = 360;
      height = 640;
    } else if (aspectRatio === '1:1') {
      width = 480;
      height = 480;
    }
    canvas.width = width;
    canvas.height = height;

    // Draw dark studio background
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, '#0a0a0c');
    gradient.addColorStop(1, '#13141a');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);

    // Subtle acoustic wave grid lines
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
    ctx.lineWidth = 1;
    for (let x = 0; x < width; x += 40) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }

    // Active Speaker Card
    const isHostActive = !activeWord || activeWord.speaker.includes('Marcus');
    
    // Draw Video Frames based on Aspect Ratio
    if (aspectRatio === '16:9') {
      // Split Screen 2-Person
      // Host side
      ctx.fillStyle = isHostActive ? '#171923' : '#111217';
      ctx.fillRect(20, 30, (width / 2) - 30, height - 120);
      ctx.strokeStyle = isHostActive ? '#3B82F6' : '#27272a';
      ctx.lineWidth = isHostActive ? 2 : 1;
      ctx.strokeRect(20, 30, (width / 2) - 30, height - 120);

      // Host avatar circle
      ctx.fillStyle = '#1e3a8a';
      ctx.beginPath();
      ctx.arc(width / 4 + 5, height / 2 - 40, 36, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#93c5fd';
      ctx.font = 'bold 20px Plus Jakarta Sans, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('MV', width / 4 + 5, height / 2 - 32);

      ctx.font = '600 12px Plus Jakarta Sans, sans-serif';
      ctx.fillStyle = '#ffffff';
      ctx.fillText('Marcus Vance (Host)', width / 4 + 5, height / 2 + 15);

      // Guest side
      ctx.fillStyle = !isHostActive ? '#171923' : '#111217';
      ctx.fillRect((width / 2) + 10, 30, (width / 2) - 30, height - 120);
      ctx.strokeStyle = !isHostActive ? '#10B981' : '#27272a';
      ctx.lineWidth = !isHostActive ? 2 : 1;
      ctx.strokeRect((width / 2) + 10, 30, (width / 2) - 30, height - 120);

      // Guest avatar circle
      ctx.fillStyle = '#064e3b';
      ctx.beginPath();
      ctx.arc((width * 3) / 4 - 5, height / 2 - 40, 36, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#6ee7b7';
      ctx.fillText('SC', (width * 3) / 4 - 5, height / 2 - 32);

      ctx.font = '600 12px Plus Jakarta Sans, sans-serif';
      ctx.fillStyle = '#ffffff';
      ctx.fillText('Sarah Chen (Guest)', (width * 3) / 4 - 5, height / 2 + 15);
    } else {
      // 9:16 Vertical Video (TikTok / Shorts Layout)
      // Top speaker
      ctx.fillStyle = isHostActive ? '#171923' : '#111217';
      ctx.fillRect(20, 40, width - 40, 180);
      ctx.strokeStyle = isHostActive ? '#3B82F6' : '#27272a';
      ctx.lineWidth = isHostActive ? 2 : 1;
      ctx.strokeRect(20, 40, width - 40, 180);

      ctx.fillStyle = '#1e3a8a';
      ctx.beginPath();
      ctx.arc(width / 2, 110, 32, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#93c5fd';
      ctx.font = 'bold 18px Plus Jakarta Sans, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('MV', width / 2, 116);
      ctx.font = '600 12px Plus Jakarta Sans, sans-serif';
      ctx.fillStyle = '#ffffff';
      ctx.fillText('Marcus Vance', width / 2, 160);

      // Bottom speaker
      ctx.fillStyle = !isHostActive ? '#171923' : '#111217';
      ctx.fillRect(20, 240, width - 40, 180);
      ctx.strokeStyle = !isHostActive ? '#10B981' : '#27272a';
      ctx.lineWidth = !isHostActive ? 2 : 1;
      ctx.strokeRect(20, 240, width - 40, 180);

      ctx.fillStyle = '#064e3b';
      ctx.beginPath();
      ctx.arc(width / 2, 310, 32, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#6ee7b7';
      ctx.fillText('SC', width / 2, 316);
      ctx.font = '600 12px Plus Jakarta Sans, sans-serif';
      ctx.fillStyle = '#ffffff';
      ctx.fillText('Sarah Chen', width / 2, 360);
    }

    // Audiogram Wave Overlay
    const waveY = aspectRatio === '9:16' ? 460 : height - 85;
    const waveWidth = width - 40;
    const barCount = 36;
    const barW = (waveWidth / barCount) - 3;

    ctx.fillStyle = isHostActive ? '#3B82F6' : '#10B981';
    for (let i = 0; i < barCount; i++) {
      const freq = Math.sin((currentTime * 8) + i * 0.4) * 0.5 + 0.5;
      const barH = isPlaying ? Math.max(4, freq * 26) : 6;
      ctx.fillRect(20 + i * (barW + 3), waveY - barH / 2, barW, barH);
    }

    // Dynamic Live Captions Rendering
    if (activeWord) {
      const captionY = height - (aspectRatio === '9:16' ? 70 : 35);

      if (captionStyle === 'karaoke') {
        // High impact TikTok subtitle
        ctx.fillStyle = 'rgba(0,0,0,0.7)';
        ctx.fillRect(16, captionY - 24, width - 32, 34);

        ctx.font = 'bold 15px Plus Jakarta Sans, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillStyle = '#FDE047'; // Bright Yellow highlight
        ctx.fillText(`“${activeWord.word}”`, width / 2, captionY);
      } else {
        ctx.font = '600 13px Plus Jakarta Sans, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillStyle = '#ffffff';
        ctx.fillText(activeWord.word, width / 2, captionY);
      }
    }
  }, [currentTime, isPlaying, aspectRatio, activeWord, captionStyle]);

  const fillerWordsCount = transcript.filter(w => w.isFiller && !w.isDeleted).length;
  const deletedWordsCount = transcript.filter(w => w.isDeleted).length;

  const formatTimelineTime = (secs: number) => {
    const mins = Math.floor(secs / 60).toString().padStart(2, '0');
    const remainingSecs = Math.floor(secs % 60).toString().padStart(2, '0');
    const ms = Math.floor((secs % 1) * 10).toString();
    return `${mins}:${remainingSecs}.${ms}`;
  };

  return (
    <div className="h-full flex flex-col bg-neutral-950 text-neutral-100 overflow-hidden">
      {/* Editor Top Command Bar */}
      <div className="h-13 border-b border-neutral-800 px-6 flex items-center justify-between bg-neutral-900/70 shrink-0">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <Type className="w-4 h-4 text-amber-400" />
            <span className="font-semibold text-sm text-neutral-100">Descript Text-Based Editor</span>
          </div>
          <span className="text-neutral-700">|</span>
          <span className="text-xs text-neutral-400">
            Click words to seek · Delete words to cut audio & video waveforms
          </span>
        </div>

        {/* 1-Click AI Cleanup & Action Buttons */}
        <div className="flex items-center gap-2.5">
          {fillerWordsCount > 0 && (
            <button
              onClick={removeAllFillerWords}
              className="px-3 py-1.5 rounded-md bg-amber-500/10 border border-amber-500/30 text-amber-300 hover:bg-amber-500/20 text-xs font-medium flex items-center gap-1.5 transition-colors"
              title="Detects and removes um, uh, like, you know"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              Remove {fillerWordsCount} Filler Words
            </button>
          )}

          <button
            onClick={trimLongPauses}
            className="px-3 py-1.5 rounded-md bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-neutral-200 text-xs font-medium flex items-center gap-1.5 transition-colors"
            title="Shorten conversational pauses > 0.8s"
          >
            <Scissors className="w-3.5 h-3.5 text-neutral-400" />
            Trim Silence Gaps
          </button>

          {selectedWordIds.size > 0 && (
            <>
              <button
                onClick={deleteSelectedWords}
                className="px-3 py-1.5 rounded-md bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Cut {selectedWordIds.size} Word{selectedWordIds.size > 1 ? 's' : ''}
              </button>

              <button
                onClick={restoreSelectedWords}
                className="px-2.5 py-1.5 rounded-md bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-neutral-300 text-xs font-medium flex items-center gap-1"
              >
                Restore
              </button>
            </>
          )}

          <button
            onClick={handleExportAsClip}
            className="px-3.5 py-1.5 rounded-md bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-colors"
          >
            <Smartphone className="w-3.5 h-3.5" />
            Export 9:16 Short
          </button>
        </div>
      </div>

      {/* Main Workspace: Left Transcript Editor + Right Video Preview */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left: Text Transcript Document (Descript-style) */}
        <div className="flex-1 flex flex-col border-r border-neutral-800/80 bg-neutral-950 overflow-hidden">
          {/* Transcript Subheader with Search & Filter */}
          <div className="px-5 py-2.5 border-b border-neutral-800/80 bg-neutral-900/40 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2 w-72 bg-neutral-900 border border-neutral-800 rounded px-2.5 py-1 text-xs">
              <Search className="w-3.5 h-3.5 text-neutral-500" />
              <input
                type="text"
                placeholder="Search transcript..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="bg-transparent border-none outline-none text-neutral-200 placeholder-neutral-500 w-full"
              />
            </div>

            <div className="flex items-center gap-3 text-xs text-neutral-400">
              <label className="flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={highlightFillerOnly}
                  onChange={e => setHighlightFillerOnly(e.target.checked)}
                  className="rounded border-neutral-700 bg-neutral-900 text-amber-500"
                />
                <span>Highlight Fillers</span>
              </label>

              {deletedWordsCount > 0 && (
                <span className="text-neutral-500 font-mono text-[11px]">
                  {deletedWordsCount} cuts active
                </span>
              )}
            </div>
          </div>

          {/* Transcript Document View */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {speakerBlocks.map((block, bIdx) => {
              const isHost = block.speaker.includes('Marcus');
              return (
                <div key={bIdx} className="space-y-1.5">
                  {/* Speaker Kicker & Timestamp */}
                  <div className="flex items-center gap-2 text-xs font-semibold">
                    <span className={isHost ? 'text-blue-400' : 'text-emerald-400'}>
                      {block.speaker}
                    </span>
                    <span className="text-neutral-600 font-mono text-[11px]">
                      {block.words[0] ? formatTimelineTime(block.words[0].start) : '00:00'}
                    </span>
                  </div>

                  {/* Word Flow Paragraph */}
                  <div className="text-[15px] leading-relaxed select-text font-normal text-neutral-200 flex flex-wrap gap-x-1 gap-y-1.5">
                    {block.words.map(w => {
                      const isWordActive = activeWord?.id === w.id;
                      const isSelected = selectedWordIds.has(w.id);
                      const matchesSearch = searchQuery && w.word.toLowerCase().includes(searchQuery.toLowerCase());

                      return (
                        <span
                          key={w.id}
                          onClick={(e) => handleWordClick(w, e)}
                          className={`cursor-pointer px-1 py-0.5 rounded transition-all duration-75 relative group ${
                            w.isDeleted
                              ? 'line-through text-neutral-600 bg-rose-950/20'
                              : isWordActive
                              ? 'bg-amber-400 text-neutral-950 font-semibold shadow-sm scale-105'
                              : isSelected
                              ? 'bg-blue-600/40 text-blue-200 ring-1 ring-blue-500'
                              : matchesSearch
                              ? 'bg-yellow-500/30 text-yellow-200 ring-1 ring-yellow-400'
                              : w.isFiller && (highlightFillerOnly || true)
                              ? 'underline decoration-amber-500/60 text-amber-200/90 hover:bg-neutral-800'
                              : 'hover:bg-neutral-800/80 hover:text-white'
                          }`}
                          title={`${w.word} (${w.start.toFixed(1)}s - ${w.end.toFixed(1)}s)${w.isFiller ? ' [Filler Word]' : ''}`}
                        >
                          {w.word}
                          {/* Deleted word restore tooltip */}
                          {w.isDeleted && (
                            <span className="hidden group-hover:block absolute -top-5 left-0 bg-neutral-900 text-[10px] text-neutral-400 px-1 py-0.5 rounded border border-neutral-700 whitespace-nowrap z-20">
                              Cut from audio (Click to select & restore)
                            </span>
                          )}
                        </span>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Video Canvas & Audiogram Compositor */}
        <div className="w-[440px] flex flex-col bg-neutral-900/30 shrink-0 border-l border-neutral-800/80">
          {/* Canvas Format Controls */}
          <div className="p-3 border-b border-neutral-800/80 flex items-center justify-between text-xs">
            <span className="font-medium text-neutral-300">Video Canvas</span>
            
            <div className="flex items-center gap-1 bg-neutral-900 border border-neutral-800 rounded p-0.5">
              <button
                onClick={() => setAspectRatio('16:9')}
                className={`px-2 py-1 rounded flex items-center gap-1 ${aspectRatio === '16:9' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400 hover:text-white'}`}
                title="Landscape (YouTube / Web)"
              >
                <Monitor className="w-3 h-3" />
                16:9
              </button>
              <button
                onClick={() => setAspectRatio('9:16')}
                className={`px-2 py-1 rounded flex items-center gap-1 ${aspectRatio === '9:16' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400 hover:text-white'}`}
                title="Vertical (TikTok / Shorts / Reels)"
              >
                <Smartphone className="w-3 h-3" />
                9:16
              </button>
              <button
                onClick={() => setAspectRatio('1:1')}
                className={`px-2 py-1 rounded flex items-center gap-1 ${aspectRatio === '1:1' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400 hover:text-white'}`}
                title="Square (Instagram / Feed)"
              >
                <Square className="w-3 h-3" />
                1:1
              </button>
            </div>
          </div>

          {/* Canvas Display Viewport */}
          <div className="flex-1 flex items-center justify-center p-4 bg-neutral-950 overflow-hidden">
            <div className="relative border border-neutral-800 rounded-lg overflow-hidden shadow-2xl bg-black">
              <canvas
                ref={canvasRef}
                className="max-h-[380px] max-w-full object-contain block"
              />
            </div>
          </div>

          {/* Caption & Audiogram Styling Settings */}
          <div className="p-4 border-t border-neutral-800/80 bg-neutral-900/60 space-y-3">
            <div>
              <div className="flex justify-between items-center text-xs mb-1.5">
                <span className="text-neutral-400">Captions Style</span>
                <span className="text-[11px] text-amber-400 font-mono">Word-by-word active</span>
              </div>
              <div className="grid grid-cols-3 gap-1.5 text-xs">
                {(['karaoke', 'bouncy', 'boxed'] as const).map(style => (
                  <button
                    key={style}
                    onClick={() => setCaptionStyle(style)}
                    className={`py-1.5 px-2 rounded border text-center capitalize transition-colors ${captionStyle === style ? 'bg-neutral-800 border-neutral-600 text-white font-medium' : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:border-neutral-700'}`}
                  >
                    {style}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between text-xs pt-1 border-t border-neutral-800/60">
              <span className="text-neutral-400">Current Playhead Word</span>
              <span className="text-neutral-200 font-mono font-medium truncate max-w-[180px]">
                {activeWord ? `"${activeWord.word}" (${activeWord.start}s)` : 'Pause/Silence'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Synchronized Multi-Track Waveform Timeline (Bottom) */}
      <div className="h-64 border-t border-neutral-800 bg-neutral-900/95 flex flex-col shrink-0">
        {/* Timeline Control Header */}
        <div className="h-11 px-5 border-b border-neutral-800/80 flex items-center justify-between bg-neutral-900 shrink-0">
          {/* Transport buttons */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setCurrentTime(0)}
              className="p-1.5 rounded hover:bg-neutral-800 text-neutral-400 hover:text-white"
              title="Return to Start"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="w-8 h-8 rounded-full bg-neutral-100 hover:bg-white text-neutral-900 flex items-center justify-center font-bold shadow transition-transform active:scale-95"
              title={isPlaying ? 'Pause (Space)' : 'Play (Space)'}
            >
              {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current translate-x-0.5" />}
            </button>

            {/* Playhead Time Counter */}
            <div className="font-mono text-sm tracking-tight text-neutral-100 px-2 py-0.5 rounded bg-neutral-950 border border-neutral-800">
              <span>{formatTimelineTime(currentTime)}</span>
              <span className="text-neutral-500 ml-1">/ {formatTimelineTime(episode.duration)}</span>
            </div>

            {/* Playback speed */}
            <select
              value={playbackRate}
              onChange={e => setPlaybackRate(Number(e.target.value))}
              className="bg-neutral-950 border border-neutral-800 rounded px-2 py-1 text-xs text-neutral-300 font-mono outline-none"
            >
              <option value="0.75">0.75x</option>
              <option value="1">1.0x</option>
              <option value="1.25">1.25x</option>
              <option value="1.5">1.5x</option>
              <option value="2">2.0x</option>
            </select>
          </div>

          {/* Timeline Zoom & Split Action */}
          <div className="flex items-center gap-3 text-xs">
            <button
              onClick={() => {
                alert(`Split clip at ${formatTimelineTime(currentTime)}!`);
              }}
              className="px-2.5 py-1 bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 rounded text-neutral-300 flex items-center gap-1.5"
            >
              <Scissors className="w-3.5 h-3.5 text-neutral-400" />
              Split at Playhead
            </button>

            <div className="flex items-center gap-1 bg-neutral-950 border border-neutral-800 rounded px-2 py-1">
              <span className="text-neutral-500 text-[11px]">Zoom:</span>
              <button
                onClick={() => setTimelineZoom(Math.max(1, timelineZoom - 0.5))}
                className="px-1 text-neutral-400 hover:text-white"
              >
                -
              </button>
              <span className="font-mono text-neutral-300 text-[11px]">{timelineZoom}x</span>
              <button
                onClick={() => setTimelineZoom(Math.min(3, timelineZoom + 0.5))}
                className="px-1 text-neutral-400 hover:text-white"
              >
                +
              </button>
            </div>
          </div>
        </div>

        {/* Tracks List + Waveform Scrubber Grid */}
        <div className="flex-1 flex overflow-hidden">
          {/* Track Headers Column (Left) */}
          <div className="w-56 border-r border-neutral-800 bg-neutral-950 shrink-0 flex flex-col justify-around py-1">
            {tracks.map(track => (
              <div key={track.id} className="px-3 py-1.5 border-b border-neutral-900 flex items-center justify-between">
                <div className="truncate pr-1">
                  <div className="text-xs font-medium text-neutral-200 truncate">{track.name}</div>
                  <div className="flex items-center gap-1 mt-0.5">
                    <button
                      onClick={() => toggleMute(track.id)}
                      className={`text-[10px] px-1 rounded font-mono font-bold ${track.muted ? 'bg-rose-900 text-rose-300' : 'bg-neutral-800 text-neutral-400 hover:text-white'}`}
                      title="Mute"
                    >
                      M
                    </button>
                    <button
                      onClick={() => toggleSolo(track.id)}
                      className={`text-[10px] px-1 rounded font-mono font-bold ${track.solo ? 'bg-amber-600 text-amber-100' : 'bg-neutral-800 text-neutral-400 hover:text-white'}`}
                      title="Solo"
                    >
                      S
                    </button>
                  </div>
                </div>

                <div className="w-16 flex items-center gap-1">
                  <Volume2 className="w-3 h-3 text-neutral-500" />
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={track.volume}
                    onChange={e => updateTrackVolume(track.id, parseFloat(e.target.value))}
                    className="w-full accent-blue-500 h-1 bg-neutral-800 rounded cursor-pointer"
                  />
                </div>
              </div>
            ))}
          </div>

          {/* Waveforms & Scrubber Timeline Area (Right) */}
          <div
            className="flex-1 relative bg-neutral-950 overflow-x-auto select-none cursor-pointer"
            onClick={e => {
              const rect = e.currentTarget.getBoundingClientRect();
              const clickX = e.clientX - rect.left;
              const ratio = Math.max(0, Math.min(1, clickX / rect.width));
              setCurrentTime(ratio * episode.duration);
            }}
          >
            {/* Time Marks Ruler */}
            <div className="h-5 border-b border-neutral-800/80 bg-neutral-900/60 flex items-center text-[10px] text-neutral-500 font-mono px-2 justify-between">
              <span>00:00</span>
              <span>00:20</span>
              <span>00:40</span>
              <span>01:00</span>
              <span>01:20</span>
              <span>01:40</span>
            </div>

            {/* Waveform Track Rows */}
            <div className="flex flex-col justify-around h-[calc(100%-20px)] py-1">
              {tracks.map(track => {
                return (
                  <div key={track.id} className="relative h-11 flex items-center px-2 border-b border-neutral-900/50">
                    {/* Render peaks */}
                    <div className="w-full h-full flex items-center gap-[2px]">
                      {track.peaks.map((peak, pIdx) => {
                        const barTime = (pIdx / track.peaks.length) * episode.duration;
                        const isCutWord = transcript.some(
                          w => w.isDeleted && barTime >= w.start && barTime <= w.end
                        );

                        return (
                          <div
                            key={pIdx}
                            className={`flex-1 rounded-sm transition-all ${
                              isCutWord
                                ? 'bg-neutral-800/30 h-1 border-t border-rose-500/40'
                                : track.muted
                                ? 'bg-neutral-700/40'
                                : barTime <= currentTime
                                ? 'bg-amber-400'
                                : track.color === '#3B82F6'
                                ? 'bg-blue-500/70'
                                : track.color === '#10B981'
                                ? 'bg-emerald-500/70'
                                : 'bg-amber-500/70'
                            }`}
                            style={{
                              height: isCutWord ? '2px' : `${Math.max(4, peak * 32)}px`
                            }}
                          />
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Playhead Red Needle */}
            <div
              className="absolute top-0 bottom-0 w-[2px] bg-rose-500 z-30 pointer-events-none"
              style={{
                left: `${(currentTime / episode.duration) * 100}%`
              }}
            >
              {/* Playhead handle top */}
              <div className="w-3 h-3 bg-rose-500 -ml-[5px] -mt-1 rounded-sm rotate-45 shadow" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
