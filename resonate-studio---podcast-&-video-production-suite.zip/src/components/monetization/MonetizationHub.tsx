import React, { useState } from 'react';
import { 
  DollarSign, Sparkles, Plus, Copy, Check, Lock, 
  TrendingUp, Users, Target, ShieldCheck, Mail, Sliders
} from 'lucide-react';
import { Episode, AdMarker } from '../../types';

interface MonetizationHubProps {
  episode: Episode;
  onUpdateEpisode: (updated: Partial<Episode>) => void;
}

export const MonetizationHub: React.FC<MonetizationHubProps> = ({
  episode,
  onUpdateEpisode
}) => {
  const [activeTab, setActiveTab] = useState<'dai' | 'calculator' | 'pitch' | 'subscriptions'>('dai');
  
  // Rate Card Calculator State
  const [downloads, setDownloads] = useState<number>(45000);
  const [cpm, setCpm] = useState<number>(38);
  const [slotsCount, setSlotsCount] = useState<number>(3); // 1 pre-roll + 2 mid-rolls
  const [episodesPerMonth, setEpisodesPerMonth] = useState<number>(4);

  // Pitch Email Generator State
  const [sponsorBrandName, setSponsorBrandName] = useState('Vercel');
  const [sponsorCategory, setSponsorCategory] = useState('Developer Tools & Cloud');
  const [isGeneratingPitch, setIsGeneratingPitch] = useState(false);
  const [pitchResult, setPitchResult] = useState<{ subject: string; body: string } | null>({
    subject: 'Partnership: The Tech Frontier Podcast x Vercel (Developer Audience)',
    body: `Hi Vercel team,\n\nI host "The Tech Frontier", an engineering & tech podcast reaching 45,000+ senior developers and founders per episode.\n\nOur audience:\n• 45,000 Verified Downloads / Episode\n• 78% Senior Engineers & Founders\n• 68% North American listenership\n\nWe have a prime mid-roll sponsor slot opening up for Q4 ($38 CPM). We integrate real developer workflows rather than reading robotic copy.\n\nWould you be open to exploring this for your Q4 developer marketing roadmap?\n\nBest,\nMarcus Vance\nHost & Producer, The Tech Frontier`
  });

  const [copiedType, setCopiedType] = useState<string | null>(null);

  // Dynamic calculations
  const revenuePerEpisode = ((downloads / 1000) * cpm) * slotsCount;
  const monthlyRevenue = revenuePerEpisode * episodesPerMonth;
  const annualRevenue = monthlyRevenue * 12;

  // New Ad Insertion Modal/State
  const [newAdTitle, setNewAdTitle] = useState('');
  const [newAdTime, setNewAdTime] = useState('00:45');
  const [newAdCpm, setNewAdCpm] = useState(35);

  const handleAddAdMarker = () => {
    if (!newAdTitle) return;
    const newAd: AdMarker = {
      id: `ad-${Date.now()}`,
      type: 'mid-roll',
      timestamp: newAdTime,
      seconds: 45,
      durationSec: 30,
      sponsorName: newAdTitle,
      cpm: newAdCpm,
      script: `This episode is sponsored by ${newAdTitle}. Visit ${newAdTitle.toLowerCase().replace(/\s/g, '')}.com/frontier for 20% off.`,
      promoCode: 'FRONTIER20',
      status: 'active'
    };

    const updatedAds = [...episode.ads, newAd];
    onUpdateEpisode({ ads: updatedAds });
    setNewAdTitle('');
  };

  const handleGeneratePitchEmail = async () => {
    setIsGeneratingPitch(true);
    try {
      const res = await fetch('/api/ai/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          task: 'sponsor_pitch',
          episodeTitle: episode.title,
          context: `${sponsorBrandName} (${sponsorCategory})`
        })
      });
      const data = await res.json();
      if (data.result && data.result.body) {
        setPitchResult(data.result);
      }
    } catch (err) {
      console.warn('AI pitch generator fallback');
    } finally {
      setIsGeneratingPitch(false);
    }
  };

  const copyText = (text: string, label: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedType(label);
    setTimeout(() => setCopiedType(null), 2000);
  };

  return (
    <div className="h-full flex flex-col bg-neutral-950 text-neutral-100 overflow-hidden">
      {/* Header */}
      <div className="h-14 border-b border-neutral-800 px-6 flex items-center justify-between bg-neutral-900/60 shrink-0">
        <div className="flex items-center gap-3">
          <DollarSign className="w-4 h-4 text-emerald-400" />
          <span className="font-semibold text-sm text-neutral-100">Monetization & Ad Engine</span>
          <span className="text-neutral-700">·</span>
          <span className="text-xs text-neutral-400 font-mono">
            Projected Run-rate: ${Math.round(annualRevenue).toLocaleString()}/year
          </span>
        </div>

        {/* Tab buttons */}
        <div className="flex items-center bg-neutral-900 border border-neutral-800 rounded-md p-0.5 text-xs">
          <button
            onClick={() => setActiveTab('dai')}
            className={`px-3 py-1.5 rounded transition-colors ${activeTab === 'dai' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400 hover:text-neutral-200'}`}
          >
            Dynamic Ad Insertion ({episode.ads.length})
          </button>
          <button
            onClick={() => setActiveTab('calculator')}
            className={`px-3 py-1.5 rounded transition-colors ${activeTab === 'calculator' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400 hover:text-neutral-200'}`}
          >
            Rate Card & Calculator
          </button>
          <button
            onClick={() => setActiveTab('pitch')}
            className={`px-3 py-1.5 rounded transition-colors ${activeTab === 'pitch' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400 hover:text-neutral-200'}`}
          >
            AI Pitch Deck & Media Kit
          </button>
          <button
            onClick={() => setActiveTab('subscriptions')}
            className={`px-3 py-1.5 rounded transition-colors ${activeTab === 'subscriptions' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400 hover:text-neutral-200'}`}
          >
            Member Paywall
          </button>
        </div>
      </div>

      {/* Main Content Viewport */}
      <div className="flex-1 overflow-y-auto p-6 max-w-5xl mx-auto w-full">
        {/* TAB 1: DYNAMIC AD INSERTION (DAI) */}
        {activeTab === 'dai' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
              <div>
                <h2 className="text-lg font-bold text-neutral-100">Dynamic Ad Insertion (DAI)</h2>
                <p className="text-xs text-neutral-400 mt-0.5">
                  Insert pre-roll, mid-roll, and post-roll sponsor reads. Ads swap dynamically on server request without re-rendering audio files.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-emerald-400 px-2 py-1 bg-emerald-950/80 border border-emerald-500/30 rounded">
                  DAI Server Engine: Active
                </span>
              </div>
            </div>

            {/* Active Ad Slots */}
            <div className="space-y-4">
              {episode.ads.map(ad => (
                <div
                  key={ad.id}
                  className="bg-neutral-900/60 border border-neutral-800 rounded-lg p-5 hover:border-neutral-700 transition-colors"
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2.5">
                      <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-500/30 uppercase">
                        {ad.type}
                      </span>
                      <h4 className="text-sm font-bold text-neutral-100">{ad.sponsorName}</h4>
                      <span className="text-neutral-600">·</span>
                      <span className="text-xs font-mono text-neutral-400">
                        At {ad.timestamp} ({ad.durationSec}s)
                      </span>
                    </div>

                    <div className="flex items-center gap-3 text-xs">
                      <span className="font-mono text-neutral-300">
                        CPM: <span className="text-emerald-400 font-bold">${ad.cpm}</span>
                      </span>
                      <span className="px-2 py-0.5 rounded bg-neutral-800 text-neutral-300 font-mono text-[11px]">
                        CODE: {ad.promoCode}
                      </span>
                    </div>
                  </div>

                  {/* Teleprompter Read Script */}
                  <div className="p-3.5 bg-neutral-950 rounded border border-neutral-800 text-xs text-neutral-300 leading-relaxed font-normal">
                    <span className="text-neutral-500 font-semibold block mb-1">Host Read Script:</span>
                    "{ad.script}"
                  </div>
                </div>
              ))}
            </div>

            {/* Add New Sponsor Slot */}
            <div className="bg-neutral-900/40 border border-neutral-800 rounded-lg p-5 space-y-4">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-neutral-300">
                Schedule New Sponsor Slot
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs text-neutral-400 mb-1">Sponsor Brand Name</label>
                  <input
                    type="text"
                    placeholder="e.g. Supabase, Notion"
                    value={newAdTitle}
                    onChange={e => setNewAdTitle(e.target.value)}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-1.5 text-xs text-neutral-200 outline-none focus:border-neutral-600"
                  />
                </div>

                <div>
                  <label className="block text-xs text-neutral-400 mb-1">Mid-Roll Timestamp</label>
                  <input
                    type="text"
                    placeholder="01:15"
                    value={newAdTime}
                    onChange={e => setNewAdTime(e.target.value)}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-1.5 text-xs text-neutral-200 outline-none font-mono focus:border-neutral-600"
                  />
                </div>

                <div>
                  <label className="block text-xs text-neutral-400 mb-1">Agreed CPM Rate ($)</label>
                  <input
                    type="number"
                    value={newAdCpm}
                    onChange={e => setNewAdCpm(Number(e.target.value))}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-1.5 text-xs text-neutral-200 outline-none font-mono focus:border-neutral-600"
                  />
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  onClick={handleAddAdMarker}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-xs font-semibold flex items-center gap-1.5 shadow"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Insert Ad Break Marker
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: RATE CARD CALCULATOR */}
        {activeTab === 'calculator' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
              <div>
                <h2 className="text-lg font-bold text-neutral-100">Sponsorship Rate Card & Projections</h2>
                <p className="text-xs text-neutral-400 mt-0.5">
                  Calculate sponsor inventory value based on verified download metrics and CPM tiers.
                </p>
              </div>
            </div>

            {/* Metrics Projection Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-neutral-900/60 border border-neutral-800 rounded-lg p-5">
                <span className="text-xs text-neutral-400 uppercase font-semibold tracking-wider">Per Episode Revenue</span>
                <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">
                  ${Math.round(revenuePerEpisode).toLocaleString()}
                </div>
                <span className="text-[11px] text-neutral-500 mt-1 block">
                  Based on {slotsCount} ad slots @ ${cpm} CPM
                </span>
              </div>

              <div className="bg-neutral-900/60 border border-neutral-800 rounded-lg p-5">
                <span className="text-xs text-neutral-400 uppercase font-semibold tracking-wider">Monthly Projection</span>
                <div className="text-2xl font-bold font-mono text-blue-400 mt-1">
                  ${Math.round(monthlyRevenue).toLocaleString()}
                </div>
                <span className="text-[11px] text-neutral-500 mt-1 block">
                  {episodesPerMonth} episodes published / month
                </span>
              </div>

              <div className="bg-neutral-900/60 border border-neutral-800 rounded-lg p-5">
                <span className="text-xs text-neutral-400 uppercase font-semibold tracking-wider">Annualized Run-Rate</span>
                <div className="text-2xl font-bold font-mono text-amber-400 mt-1">
                  ${Math.round(annualRevenue).toLocaleString()}
                </div>
                <span className="text-[11px] text-neutral-500 mt-1 block">
                  12-month commercial inventory
                </span>
              </div>
            </div>

            {/* Interactive Sliders */}
            <div className="bg-neutral-900/60 border border-neutral-800 rounded-lg p-6 space-y-6">
              <div>
                <div className="flex justify-between items-center text-xs mb-2">
                  <span className="text-neutral-300 font-medium">Verified 30-Day Downloads per Episode</span>
                  <span className="font-mono text-emerald-400 font-bold">{downloads.toLocaleString()} downloads</span>
                </div>
                <input
                  type="range"
                  min="5000"
                  max="200000"
                  step="5000"
                  value={downloads}
                  onChange={e => setDownloads(Number(e.target.value))}
                  className="w-full accent-emerald-500 h-1.5 bg-neutral-800 rounded cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between items-center text-xs mb-2">
                  <span className="text-neutral-300 font-medium">Average CPM Rate (Cost Per Mille)</span>
                  <span className="font-mono text-blue-400 font-bold">${cpm} / 1,000 listens</span>
                </div>
                <input
                  type="range"
                  min="18"
                  max="60"
                  step="1"
                  value={cpm}
                  onChange={e => setCpm(Number(e.target.value))}
                  className="w-full accent-blue-500 h-1.5 bg-neutral-800 rounded cursor-pointer"
                />
              </div>

              <div className="grid grid-cols-2 gap-4 pt-2">
                <div>
                  <label className="text-xs text-neutral-400 block mb-1">Ad Slots per Episode</label>
                  <select
                    value={slotsCount}
                    onChange={e => setSlotsCount(Number(e.target.value))}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-1.5 text-xs text-neutral-200 outline-none"
                  >
                    <option value="1">1 Slot (1 Mid-roll)</option>
                    <option value="2">2 Slots (1 Pre + 1 Mid)</option>
                    <option value="3">3 Slots (1 Pre + 2 Mids)</option>
                    <option value="4">4 Slots (1 Pre + 2 Mids + 1 Post)</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs text-neutral-400 block mb-1">Episodes Published / Month</label>
                  <select
                    value={episodesPerMonth}
                    onChange={e => setEpisodesPerMonth(Number(e.target.value))}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-1.5 text-xs text-neutral-200 outline-none"
                  >
                    <option value="2">Bi-weekly (2 episodes)</option>
                    <option value="4">Weekly (4 episodes)</option>
                    <option value="8">Twice weekly (8 episodes)</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: AI SPONSOR PITCH & MEDIA KIT */}
        {activeTab === 'pitch' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
              <div>
                <h2 className="text-lg font-bold text-neutral-100">AI Sponsor Pitch Deck & Outreach</h2>
                <p className="text-xs text-neutral-400 mt-0.5">
                  Generate customized, high-converting partnership emails targeting developer & B2B brands.
                </p>
              </div>
            </div>

            {/* Target brand inputs */}
            <div className="bg-neutral-900/60 border border-neutral-800 rounded-lg p-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                <div>
                  <label className="block text-xs text-neutral-400 mb-1">Target Brand Name</label>
                  <input
                    type="text"
                    value={sponsorBrandName}
                    onChange={e => setSponsorBrandName(e.target.value)}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-1.5 text-xs text-neutral-200 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs text-neutral-400 mb-1">Industry / Category</label>
                  <input
                    type="text"
                    value={sponsorCategory}
                    onChange={e => setSponsorCategory(e.target.value)}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-1.5 text-xs text-neutral-200 outline-none"
                  />
                </div>
              </div>

              <button
                onClick={handleGeneratePitchEmail}
                disabled={isGeneratingPitch}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-xs font-semibold flex items-center gap-1.5 shadow"
              >
                <Sparkles className="w-3.5 h-3.5" />
                {isGeneratingPitch ? 'Crafting Pitch with Gemini...' : 'Generate Custom Pitch Email'}
              </button>
            </div>

            {/* Pitch Output */}
            {pitchResult && (
              <div className="bg-neutral-900/60 border border-neutral-800 rounded-lg p-5 space-y-3">
                <div className="flex justify-between items-center pb-2 border-b border-neutral-800">
                  <div className="text-xs text-neutral-400">
                    Subject: <span className="text-neutral-200 font-medium">{pitchResult.subject}</span>
                  </div>
                  <button
                    onClick={() => copyText(`${pitchResult.subject}\n\n${pitchResult.body}`, 'pitch')}
                    className="px-3 py-1 bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 rounded text-xs text-neutral-200 flex items-center gap-1"
                  >
                    {copiedType === 'pitch' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    Copy Pitch
                  </button>
                </div>

                <pre className="text-xs text-neutral-300 font-mono whitespace-pre-wrap leading-relaxed bg-neutral-950 p-4 rounded border border-neutral-800">
                  {pitchResult.body}
                </pre>
              </div>
            )}
          </div>
        )}

        {/* TAB 4: MEMBER PAYWALL */}
        {activeTab === 'subscriptions' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
              <div>
                <h2 className="text-lg font-bold text-neutral-100">Subscriber & Member Exclusives</h2>
                <p className="text-xs text-neutral-400 mt-0.5">
                  Patreon, Supercast, and Apple Podcasts Subscriptions gate for ad-free feeds and extended cuts.
                </p>
              </div>
            </div>

            <div className="bg-neutral-900/60 border border-neutral-800 rounded-lg p-6 max-w-xl mx-auto text-center space-y-4">
              <div className="w-12 h-12 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center mx-auto">
                <Lock className="w-6 h-6" />
              </div>

              <div>
                <h3 className="text-sm font-bold text-neutral-100">Bonus Segment: Uncut Studio Q&A</h3>
                <p className="text-xs text-neutral-400 mt-1">
                  Available exclusively to VIP & Founding Members. 18 minutes of unedited raw discussion with Sarah Chen.
                </p>
              </div>

              <div className="p-3 bg-neutral-950 rounded border border-neutral-800 text-xs font-mono text-neutral-400 flex items-center justify-center gap-2">
                <span>Audio Lock: Active</span>
                <span>·</span>
                <span className="text-emerald-400">820 Active Subscribers</span>
              </div>

              <button
                onClick={() => alert('Subscriber feed settings saved!')}
                className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-neutral-200 text-xs font-medium rounded"
              >
                Configure Subscriber RSS Gate
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
