import React, { useState } from 'react';
import { 
  FileText, Sparkles, Download, Copy, Check, Clock, 
  Share2, Video, TrendingUp, RefreshCw, BookmarkCheck, ListChecks,
  Quote, ExternalLink
} from 'lucide-react';
import { Episode, Chapter, VideoClip, ShowNotes } from '../../types';

interface TranscriptionHubProps {
  episode: Episode;
  onUpdateEpisode: (updated: Partial<Episode>) => void;
  onAddShortsClip: (clip: VideoClip) => void;
  onSelectTab: (tab: any) => void;
}

export const TranscriptionHub: React.FC<TranscriptionHubProps> = ({
  episode,
  onUpdateEpisode,
  onAddShortsClip,
  onSelectTab
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'transcript' | 'shownotes' | 'chapters' | 'shorts'>('shownotes');
  const [isLoadingAi, setIsLoadingAi] = useState(false);
  const [copiedType, setCopiedType] = useState<string | null>(null);

  // Helper copy function
  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedType(type);
    setTimeout(() => setCopiedType(null), 2000);
  };

  // Generate Show Notes via AI endpoint
  const handleGenerateShowNotes = async () => {
    setIsLoadingAi(true);
    try {
      const fullTranscriptText = episode.transcript
        .filter(w => !w.isDeleted)
        .map(w => w.word)
        .join(' ');

      const res = await fetch('/api/ai/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          task: 'show_notes',
          episodeTitle: episode.title,
          transcriptText: fullTranscriptText
        })
      });

      const data = await res.json();
      if (data.result && data.result.summary) {
        onUpdateEpisode({ showNotes: data.result });
      }
    } catch (err) {
      console.warn('AI call error, retaining current show notes');
    } finally {
      setIsLoadingAi(false);
    }
  };

  // Generate Chapters via AI endpoint
  const handleGenerateChapters = async () => {
    setIsLoadingAi(true);
    try {
      const fullTranscriptText = episode.transcript
        .filter(w => !w.isDeleted)
        .map(w => w.word)
        .join(' ');

      const res = await fetch('/api/ai/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          task: 'chapters',
          episodeTitle: episode.title,
          transcriptText: fullTranscriptText
        })
      });

      const data = await res.json();
      if (Array.isArray(data.result)) {
        const mappedChapters: Chapter[] = data.result.map((ch: any, i: number) => ({
          id: `ch-ai-${i}`,
          title: ch.title,
          timestamp: ch.timestamp,
          seconds: parseTimestampToSeconds(ch.timestamp),
          description: ch.description || ''
        }));
        onUpdateEpisode({ chapters: mappedChapters });
      }
    } catch (err) {
      console.warn('AI chapters error');
    } finally {
      setIsLoadingAi(false);
    }
  };

  // Generate Viral Shorts via AI endpoint
  const handleGenerateViralShorts = async () => {
    setIsLoadingAi(true);
    try {
      const fullTranscriptText = episode.transcript
        .filter(w => !w.isDeleted)
        .map(w => w.word)
        .join(' ');

      const res = await fetch('/api/ai/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          task: 'viral_shorts',
          episodeTitle: episode.title,
          transcriptText: fullTranscriptText
        })
      });

      const data = await res.json();
      if (Array.isArray(data.result)) {
        const mappedClips: VideoClip[] = data.result.map((item: any, i: number) => ({
          id: `clip-ai-${i}-${Date.now()}`,
          title: item.title,
          startTime: parseTimestampToSeconds(item.startTime || '00:30'),
          endTime: parseTimestampToSeconds(item.endTime || '01:00'),
          aspectRatio: '9:16',
          hookText: item.hookText,
          viralScore: item.viralScore || 90,
          captionStyle: 'karaoke',
          reason: item.reason
        }));
        onUpdateEpisode({ clips: mappedClips });
      }
    } catch (err) {
      console.warn('AI shorts error');
    } finally {
      setIsLoadingAi(false);
    }
  };

  const parseTimestampToSeconds = (ts: string) => {
    const parts = ts.split(':').map(Number);
    if (parts.length === 2) return parts[0] * 60 + parts[1];
    if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
    return 0;
  };

  // Export formats
  const exportSRT = () => {
    let srt = '';
    let counter = 1;
    let currentBlockWords: typeof episode.transcript = [];
    
    episode.transcript.forEach((w, i) => {
      if (w.isDeleted) return;
      currentBlockWords.push(w);
      if (currentBlockWords.length >= 8 || i === episode.transcript.length - 1) {
        const start = formatSrtTime(currentBlockWords[0].start);
        const end = formatSrtTime(currentBlockWords[currentBlockWords.length - 1].end);
        const text = currentBlockWords.map(bw => bw.word).join(' ');
        srt += `${counter}\n${start} --> ${end}\n${text}\n\n`;
        counter++;
        currentBlockWords = [];
      }
    });

    downloadBlob(srt, `${episode.id}-subtitles.srt`, 'text/plain');
  };

  const formatSrtTime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600).toString().padStart(2, '0');
    const mins = Math.floor((seconds % 3600) / 60).toString().padStart(2, '0');
    const secs = Math.floor(seconds % 60).toString().padStart(2, '0');
    const ms = Math.floor((seconds % 1) * 1000).toString().padStart(3, '0');
    return `${hrs}:${mins}:${secs},${ms}`;
  };

  const downloadBlob = (content: string, filename: string, mime: string) => {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="h-full flex flex-col bg-neutral-950 text-neutral-100 overflow-hidden">
      {/* Header bar */}
      <div className="h-14 border-b border-neutral-800 px-6 flex items-center justify-between bg-neutral-900/60 shrink-0">
        <div className="flex items-center gap-3">
          <FileText className="w-4 h-4 text-emerald-400" />
          <span className="font-semibold text-sm text-neutral-100">AI Transcription & Producer Hub</span>
          <span className="text-neutral-700">·</span>
          <span className="text-xs text-neutral-400 font-mono">
            {episode.transcript.filter(w => !w.isDeleted).length} active words diarized
          </span>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center bg-neutral-900 border border-neutral-800 rounded-md p-0.5 text-xs">
          <button
            onClick={() => setActiveSubTab('shownotes')}
            className={`px-3 py-1.5 rounded transition-colors ${activeSubTab === 'shownotes' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400 hover:text-neutral-200'}`}
          >
            Show Notes
          </button>
          <button
            onClick={() => setActiveSubTab('chapters')}
            className={`px-3 py-1.5 rounded transition-colors ${activeSubTab === 'chapters' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400 hover:text-neutral-200'}`}
          >
            Chapters ({episode.chapters.length})
          </button>
          <button
            onClick={() => setActiveSubTab('shorts')}
            className={`px-3 py-1.5 rounded transition-colors ${activeSubTab === 'shorts' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400 hover:text-neutral-200'}`}
          >
            Viral Shorts ({episode.clips.length})
          </button>
          <button
            onClick={() => setActiveSubTab('transcript')}
            className={`px-3 py-1.5 rounded transition-colors ${activeSubTab === 'transcript' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400 hover:text-neutral-200'}`}
          >
            Raw Transcript
          </button>
        </div>
      </div>

      {/* Main SubTab Contents */}
      <div className="flex-1 overflow-y-auto p-6 max-w-5xl mx-auto w-full">
        {/* SUBTAB 1: AI SHOW NOTES */}
        {activeSubTab === 'shownotes' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
              <div>
                <h2 className="text-lg font-bold text-neutral-100">Automated Episode Show Notes</h2>
                <p className="text-xs text-neutral-400 mt-0.5">
                  AI-curated executive summary, key insights, quotes, and resources for newsletter and podcast feeds.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleGenerateShowNotes}
                  disabled={isLoadingAi}
                  className="px-3.5 py-1.5 rounded-md bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-colors disabled:opacity-50"
                >
                  <Sparkles className={`w-3.5 h-3.5 ${isLoadingAi ? 'animate-spin' : ''}`} />
                  {isLoadingAi ? 'Regenerating...' : 'Regenerate with Gemini'}
                </button>

                <button
                  onClick={() => {
                    const text = `# ${episode.title}\n\n## Summary\n${episode.showNotes.summary}\n\n## Key Takeaways\n${episode.showNotes.keyTakeaways.map(k => `• ${k}`).join('\n')}\n\n## Quotes\n${episode.showNotes.memorableQuotes.map(q => `> ${q}`).join('\n')}`;
                    copyToClipboard(text, 'shownotes');
                  }}
                  className="px-3 py-1.5 rounded-md bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-neutral-200 text-xs font-medium flex items-center gap-1.5"
                >
                  {copiedType === 'shownotes' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedType === 'shownotes' ? 'Copied Markdown' : 'Copy All'}
                </button>
              </div>
            </div>

            {/* Summary Box */}
            <div className="bg-neutral-900/60 border border-neutral-800 rounded-lg p-5">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-2 flex items-center gap-2">
                <FileText className="w-3.5 h-3.5 text-emerald-400" />
                Executive Summary
              </h3>
              <p className="text-sm text-neutral-200 leading-relaxed">
                {episode.showNotes.summary}
              </p>
            </div>

            {/* Key Insights Grid */}
            <div className="bg-neutral-900/60 border border-neutral-800 rounded-lg p-5">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-3 flex items-center gap-2">
                <ListChecks className="w-3.5 h-3.5 text-blue-400" />
                Key Takeaways
              </h3>
              <ul className="space-y-2.5">
                {episode.showNotes.keyTakeaways.map((point, idx) => (
                  <li key={idx} className="flex items-start gap-2.5 text-sm text-neutral-300">
                    <span className="text-blue-400 font-bold mt-0.5">•</span>
                    <span>{point}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Memorable Quotes */}
            <div className="bg-neutral-900/60 border border-neutral-800 rounded-lg p-5">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-3 flex items-center gap-2">
                <Quote className="w-3.5 h-3.5 text-amber-400" />
                Memorable Quotes
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {episode.showNotes.memorableQuotes.map((q, idx) => (
                  <div key={idx} className="p-3 bg-neutral-950/60 rounded border border-neutral-800/80 text-xs italic text-neutral-200">
                    {q}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* SUBTAB 2: CHAPTER MARKERS */}
        {activeSubTab === 'chapters' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
              <div>
                <h2 className="text-lg font-bold text-neutral-100">Smart Chapter Markers</h2>
                <p className="text-xs text-neutral-400 mt-0.5">
                  Timestamped chapters for YouTube description navigation and Apple Podcasts ID3 chapter frames.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleGenerateChapters}
                  disabled={isLoadingAi}
                  className="px-3.5 py-1.5 rounded-md bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors disabled:opacity-50"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  Auto-Detect Chapters
                </button>

                <button
                  onClick={() => {
                    const text = episode.chapters.map(c => `${c.timestamp} - ${c.title}`).join('\n');
                    copyToClipboard(text, 'ytchapters');
                  }}
                  className="px-3 py-1.5 rounded-md bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-neutral-200 text-xs font-medium flex items-center gap-1.5"
                >
                  {copiedType === 'ytchapters' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  Copy for YouTube
                </button>
              </div>
            </div>

            <div className="space-y-3">
              {episode.chapters.map((ch, idx) => (
                <div
                  key={ch.id}
                  className="flex items-center justify-between p-4 bg-neutral-900/60 border border-neutral-800 rounded-lg hover:border-neutral-700 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <span className="font-mono text-xs px-2.5 py-1 bg-neutral-950 border border-neutral-800 rounded text-emerald-400 font-bold">
                      {ch.timestamp}
                    </span>
                    <div>
                      <h4 className="text-sm font-semibold text-neutral-200">{ch.title}</h4>
                      <p className="text-xs text-neutral-400 mt-0.5">{ch.description}</p>
                    </div>
                  </div>

                  <button
                    onClick={() => onSelectTab('editor')}
                    className="text-xs text-neutral-400 hover:text-white px-2.5 py-1 rounded bg-neutral-800/80 border border-neutral-700/60"
                  >
                    Seek in Timeline
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* SUBTAB 3: VIRAL SHORTS FINDER */}
        {activeSubTab === 'shorts' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
              <div>
                <h2 className="text-lg font-bold text-neutral-100">AI Viral Shorts & Reels Generator</h2>
                <p className="text-xs text-neutral-400 mt-0.5">
                  AI scans audio pacing and conversation peaks to package 30s-60s vertical clips for TikTok and YouTube Shorts.
                </p>
              </div>

              <button
                onClick={handleGenerateViralShorts}
                disabled={isLoadingAi}
                className="px-3.5 py-1.5 rounded-md bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors disabled:opacity-50"
              >
                <Sparkles className="w-3.5 h-3.5" />
                Find New Viral Clips
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {episode.clips.map(clip => (
                <div
                  key={clip.id}
                  className="bg-neutral-900/60 border border-neutral-800 rounded-lg p-5 flex flex-col justify-between hover:border-neutral-700 transition-colors"
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-indigo-950/80 border border-indigo-500/30 text-indigo-300">
                        {clip.aspectRatio} Vertical Video
                      </span>
                      <div className="flex items-center gap-1.5 text-xs text-amber-400 font-mono font-bold">
                        <TrendingUp className="w-3.5 h-3.5" />
                        Virality: {clip.viralScore}/100
                      </div>
                    </div>

                    <h4 className="text-sm font-bold text-neutral-100 mb-2">{clip.title}</h4>

                    <div className="p-3 bg-neutral-950 rounded border border-neutral-800 text-xs text-neutral-300 mb-3">
                      <span className="text-neutral-500 font-semibold block mb-1">Hook Opening:</span>
                      "{clip.hookText}"
                    </div>

                    {clip.reason && (
                      <p className="text-xs text-neutral-400 mb-3">
                        <span className="text-neutral-300 font-medium">Why it works:</span> {clip.reason}
                      </p>
                    )}
                  </div>

                  <div className="pt-3 border-t border-neutral-800 flex items-center justify-between">
                    <span className="text-xs text-neutral-500 font-mono">
                      {Math.floor(clip.startTime / 60)}:{(clip.startTime % 60).toString().padStart(2, '0')} - {Math.floor(clip.endTime / 60)}:{(clip.endTime % 60).toString().padStart(2, '0')} ({clip.endTime - clip.startTime}s)
                    </span>

                    <button
                      onClick={() => onSelectTab('editor')}
                      className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 rounded text-xs font-semibold text-white flex items-center gap-1.5"
                    >
                      <Video className="w-3.5 h-3.5 text-indigo-400" />
                      Open in Video Canvas
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* SUBTAB 4: RAW TRANSCRIPT & EXPORT */}
        {activeSubTab === 'transcript' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
              <div>
                <h2 className="text-lg font-bold text-neutral-100">Export Diarized Transcript</h2>
                <p className="text-xs text-neutral-400 mt-0.5">
                  Standard SRT subtitle files, WebVTT, and JSON export.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={exportSRT}
                  className="px-3.5 py-1.5 bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 rounded-md text-xs font-medium text-neutral-200 flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5 text-emerald-400" />
                  Download SRT Subtitles
                </button>

                <button
                  onClick={() => {
                    const txt = episode.transcript.filter(w => !w.isDeleted).map(w => w.word).join(' ');
                    downloadBlob(txt, `${episode.id}-transcript.txt`, 'text/plain');
                  }}
                  className="px-3.5 py-1.5 bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 rounded-md text-xs font-medium text-neutral-200 flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5 text-blue-400" />
                  Download Plain Text
                </button>
              </div>
            </div>

            <div className="bg-neutral-900/60 border border-neutral-800 rounded-lg p-5 font-mono text-xs text-neutral-300 leading-relaxed max-h-[500px] overflow-y-auto select-text">
              {episode.transcript
                .filter(w => !w.isDeleted)
                .map(w => w.word)
                .join(' ')}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
