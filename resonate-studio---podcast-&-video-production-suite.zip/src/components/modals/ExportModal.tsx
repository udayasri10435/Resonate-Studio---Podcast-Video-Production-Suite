import React, { useState } from 'react';
import { X, Download, FileAudio, Video, FileText, CheckCircle2, Sparkles } from 'lucide-react';
import { Episode } from '../../types';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  episode: Episode;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  episode
}) => {
  if (!isOpen) return null;

  const [exportFormat, setExportFormat] = useState<'mp3' | 'wav' | 'video' | 'subtitles'>('mp3');
  const [isExporting, setIsExporting] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  const handleStartExport = () => {
    setIsExporting(true);
    setDownloadSuccess(false);

    setTimeout(() => {
      setIsExporting(false);
      setDownloadSuccess(true);

      // Trigger dummy download
      const filename = `${episode.id}-${exportFormat}.${exportFormat === 'video' ? 'mp4' : exportFormat === 'subtitles' ? 'srt' : exportFormat}`;
      const dummyData = `Resonate Studio Export: ${episode.title}\nFormat: ${exportFormat.toUpperCase()}\nDuration: ${episode.duration}s\nExported at: ${new Date().toISOString()}`;
      const blob = new Blob([dummyData], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      a.click();
      URL.revokeObjectURL(url);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl w-full max-w-md overflow-hidden shadow-2xl animate-in fade-in zoom-in-95">
        {/* Modal Header */}
        <div className="p-4 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Download className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-bold text-neutral-100">Export Production Master</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-neutral-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-4">
          <div>
            <label className="text-xs font-medium text-neutral-300 block mb-2">Select Export Target</label>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                onClick={() => setExportFormat('mp3')}
                className={`p-3 rounded-lg border text-left transition-colors flex flex-col gap-1 ${exportFormat === 'mp3' ? 'bg-neutral-800 border-neutral-600 text-white' : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:border-neutral-700'}`}
              >
                <div className="flex items-center gap-1.5 font-semibold text-neutral-200">
                  <FileAudio className="w-3.5 h-3.5 text-blue-400" />
                  MP3 (320 kbps)
                </div>
                <span className="text-[10px] text-neutral-500">Universal Podcast Master</span>
              </button>

              <button
                onClick={() => setExportFormat('wav')}
                className={`p-3 rounded-lg border text-left transition-colors flex flex-col gap-1 ${exportFormat === 'wav' ? 'bg-neutral-800 border-neutral-600 text-white' : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:border-neutral-700'}`}
              >
                <div className="flex items-center gap-1.5 font-semibold text-neutral-200">
                  <FileAudio className="w-3.5 h-3.5 text-emerald-400" />
                  WAV Lossless
                </div>
                <span className="text-[10px] text-neutral-500">48kHz / 24-bit Archival</span>
              </button>

              <button
                onClick={() => setExportFormat('video')}
                className={`p-3 rounded-lg border text-left transition-colors flex flex-col gap-1 ${exportFormat === 'video' ? 'bg-neutral-800 border-neutral-600 text-white' : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:border-neutral-700'}`}
              >
                <div className="flex items-center gap-1.5 font-semibold text-neutral-200">
                  <Video className="w-3.5 h-3.5 text-purple-400" />
                  1080p MP4 Video
                </div>
                <span className="text-[10px] text-neutral-500">With Burned-In Captions</span>
              </button>

              <button
                onClick={() => setExportFormat('subtitles')}
                className={`p-3 rounded-lg border text-left transition-colors flex flex-col gap-1 ${exportFormat === 'subtitles' ? 'bg-neutral-800 border-neutral-600 text-white' : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:border-neutral-700'}`}
              >
                <div className="flex items-center gap-1.5 font-semibold text-neutral-200">
                  <FileText className="w-3.5 h-3.5 text-amber-400" />
                  SRT Subtitles
                </div>
                <span className="text-[10px] text-neutral-500">Timestamped Diarization</span>
              </button>
            </div>
          </div>

          <div className="p-3 bg-neutral-950 rounded-lg border border-neutral-800 text-xs text-neutral-400 space-y-1">
            <div className="flex justify-between">
              <span>Episode:</span>
              <span className="text-neutral-200 font-medium truncate max-w-[200px]">{episode.title}</span>
            </div>
            <div className="flex justify-between">
              <span>Duration:</span>
              <span className="text-neutral-200 font-mono">1m 38s (Cleaned)</span>
            </div>
            <div className="flex justify-between">
              <span>Edits Applied:</span>
              <span className="text-emerald-400 font-mono">Filler words cut · Silence trimmed</span>
            </div>
          </div>

          {downloadSuccess && (
            <div className="p-2.5 rounded bg-emerald-950/80 border border-emerald-500/30 text-xs text-emerald-400 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>Export compiled and downloaded successfully!</span>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-neutral-800 bg-neutral-950 flex items-center justify-end gap-2">
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded text-xs text-neutral-400 hover:text-white"
          >
            Cancel
          </button>
          <button
            onClick={handleStartExport}
            disabled={isExporting}
            className="px-4 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors disabled:opacity-50"
          >
            <Sparkles className={`w-3.5 h-3.5 ${isExporting ? 'animate-spin' : ''}`} />
            {isExporting ? 'Rendering Audio Buffer...' : `Export ${exportFormat.toUpperCase()}`}
          </button>
        </div>
      </div>
    </div>
  );
};
