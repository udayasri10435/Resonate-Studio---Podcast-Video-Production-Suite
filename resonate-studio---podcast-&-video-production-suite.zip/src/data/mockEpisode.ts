import { Episode, TranscriptWord } from '../types';

// Helper to generate natural waveform peaks
export function generateWaveformPeaks(count: number, seed: number = 1): number[] {
  const peaks: number[] = [];
  let prev = 0.4;
  for (let i = 0; i < count; i++) {
    // Generate speech bursts and small pauses
    const burst = Math.sin(i * 0.12 * seed) * 0.35 + Math.cos(i * 0.28 * seed) * 0.25;
    const noise = (Math.random() - 0.5) * 0.3;
    let val = Math.max(0.08, Math.min(0.96, Math.abs(prev * 0.6 + burst * 0.3 + noise)));
    
    // Inject occasional conversational pauses
    if (i % 24 > 20) {
      val = 0.05 + Math.random() * 0.08;
    }
    prev = val;
    peaks.push(Number(val.toFixed(2)));
  }
  return peaks;
}

const rawScript = [
  { speaker: 'Marcus Vance (Host)', text: 'Welcome back to The Tech Frontier. Today, we are recording live from our multi-track studio, and we are diving into why traditional video and audio editing is fundamentally broken.' },
  { speaker: 'Marcus Vance (Host)', text: 'Um, for the longest time, creators had to scrub through hours of raw waveforms just to cut out a simple stutter or pause.' },
  { speaker: 'Sarah Chen (Guest)', text: 'Exactly, Marcus. Like, when you look at how timeline editors were designed thirty years ago, they were built for tape reels and linear cinema workflows.' },
  { speaker: 'Sarah Chen (Guest)', text: 'Uh, with text-based editing, you treat spoken media exactly like a document. If you delete a sentence on the page, the audio cuts right with it.' },
  { speaker: 'Marcus Vance (Host)', text: 'And that is the magic. You know, you do not need five years of Premiere or Pro Tools training. You simply highlight the filler words, hit delete, and your timeline snaps into place.' },
  { speaker: 'Sarah Chen (Guest)', text: 'Plus, look at what Riverside pioneered with local-track recording. By recording uncompressed audio locally in the browser, you never get that terrible robotic Zoom compression when someone bandwidth drops.' },
  { speaker: 'Marcus Vance (Host)', text: 'Actually, we are running that exact engine right now. 48 kilohertz, 24-bit studio capture, with instant server sync.' },
  { speaker: 'Marcus Vance (Host)', text: 'Let us take a quick break for our partner, CloudScale AI, before we discuss how dynamic ad insertion is unlocking twenty thousand dollars a month for solo producers.' },
  { speaker: 'Sarah Chen (Guest)', text: 'Looking forward to that, because monetization is where most independent podcasters get stuck.' }
];

// Generate timestamped words from the script
export function buildInitialTranscript(): TranscriptWord[] {
  const words: TranscriptWord[] = [];
  let currentTime = 1.2;

  rawScript.forEach((block, blockIdx) => {
    const tokens = block.text.split(' ');
    tokens.forEach((token, tokenIdx) => {
      // Clean word
      const clean = token.replace(/[^a-zA-Z0-9']/g, '').toLowerCase();
      const isFiller = ['um', 'uh', 'like', 'you', 'know', 'actually'].includes(clean);
      const duration = 0.28 + (token.length * 0.04) + (Math.random() * 0.1);
      const start = Number(currentTime.toFixed(2));
      const end = Number((currentTime + duration).toFixed(2));
      currentTime = end + (token.endsWith('.') || token.endsWith('?') ? 0.35 : 0.05);

      words.push({
        id: `word-${blockIdx}-${tokenIdx}-${Math.random().toString(36).substring(2, 6)}`,
        word: token,
        start,
        end,
        speaker: block.speaker,
        isFiller,
        isDeleted: false,
        confidence: isFiller ? 0.88 : 0.98
      });
    });
  });

  return words;
}

export const initialEpisode: Episode = {
  id: 'ep-042',
  title: 'Ep 42: The Autonomous Media Engine - Text Editing & Local Broadcast',
  subtitle: 'Marcus Vance & Sarah Chen dissect the future of Riverside-style recording and Descript-style text editing.',
  episodeNumber: 42,
  season: 3,
  duration: 98, // 1m 38s sample episode
  status: 'editing',
  recordedAt: 'Today, 10:30 AM',
  coverArt: '',
  tracks: [
    {
      id: 'track-host',
      name: 'Host Mic (Marcus Vance)',
      type: 'host',
      volume: 0.92,
      muted: false,
      solo: false,
      color: '#3B82F6', // Blue
      peaks: generateWaveformPeaks(120, 1.4)
    },
    {
      id: 'track-guest',
      name: 'Guest Mic (Sarah Chen)',
      type: 'guest',
      volume: 0.88,
      muted: false,
      solo: false,
      color: '#10B981', // Emerald
      peaks: generateWaveformPeaks(120, 2.1)
    },
    {
      id: 'track-sfx',
      name: 'Studio Soundboard & Music',
      type: 'sfx',
      volume: 0.65,
      muted: false,
      solo: false,
      color: '#F59E0B', // Amber
      peaks: generateWaveformPeaks(120, 0.7)
    }
  ],
  transcript: buildInitialTranscript(),
  chapters: [
    { id: 'ch-1', title: 'Welcome & The Timeline Tax', timestamp: '00:00', seconds: 0, description: 'Marcus Vance welcomes listeners to the studio.' },
    { id: 'ch-2', title: 'Why 30-Year-Old NLE Workflows Fail', timestamp: '00:15', seconds: 15, description: 'Sarah Chen breaks down linear editing constraints.' },
    { id: 'ch-3', title: 'Text-Based Editing in Action', timestamp: '00:38', seconds: 38, description: 'Highlighting and deleting words to cut waveforms.' },
    { id: 'ch-4', title: 'Riverside-Style Local Track Quality', timestamp: '00:58', seconds: 58, description: 'Why local uncompressed capture beats streaming audio.' },
    { id: 'ch-5', title: 'Mid-Roll Sponsor: CloudScale AI', timestamp: '01:21', seconds: 81, description: 'Dynamic ad insertion demo.' }
  ],
  ads: [
    {
      id: 'ad-1',
      type: 'pre-roll',
      timestamp: '00:00',
      seconds: 0,
      durationSec: 15,
      sponsorName: 'Linear Workspace',
      cpm: 32,
      script: 'This episode is brought to you by Linear - the issue tracking and project tool built specifically for high-velocity software engineering teams.',
      promoCode: 'RESONATE20',
      status: 'active'
    },
    {
      id: 'ad-2',
      type: 'mid-roll',
      timestamp: '01:21',
      seconds: 81,
      durationSec: 30,
      sponsorName: 'CloudScale AI',
      cpm: 45,
      script: 'Support for The Tech Frontier comes from CloudScale AI. Automate your cloud telemetry and eliminate downtime with autonomous agent clusters.',
      promoCode: 'TECHFRONTIER',
      status: 'active'
    }
  ],
  clips: [
    {
      id: 'clip-1',
      title: 'Never Drag a Playhead Again (Text Editing)',
      startTime: 38,
      endTime: 58,
      aspectRatio: '9:16',
      hookText: 'You will never drag an audio timeline again.',
      viralScore: 97,
      captionStyle: 'karaoke',
      reason: 'Immediate visual realization of editing video by deleting words.'
    },
    {
      id: 'clip-2',
      title: 'Stop Using Zoom for Podcasts',
      startTime: 58,
      endTime: 80,
      aspectRatio: '9:16',
      hookText: 'Why Zoom audio sounds like a 2004 flip phone.',
      viralScore: 93,
      captionStyle: 'bouncy',
      reason: 'Direct callout of bad audio habits with high controversy rate.'
    }
  ],
  showNotes: {
    summary: 'Marcus Vance and Sarah Chen break down how next-generation podcast production suites combine local multi-track recording (Riverside) with text-based editing (Descript). They explore the architectural differences between stream ripping and browser-local capture, demonstrating how editing transcript words cuts waveforms in real time.',
    keyTakeaways: [
      'Text-based editing brings the speed of text manipulation to audio/video production.',
      'Local-track studio recording captures 48kHz audio directly on each client device, eliminating dropouts.',
      'Automated filler-word removal and gap trimming can cut post-production time by 70%.',
      'Dynamic Ad Insertion (DAI) allows back-catalog monetization without re-rendering past episodes.'
    ],
    memorableQuotes: [
      '“If you can edit a Google Doc, you can now produce a broadcast-quality production.”',
      '“The friction between having an idea and shipping a global broadcast has dropped to near zero.”'
    ],
    resources: [
      'Resonate Studio Studio Core (Local Web Audio Pipeline)',
      'Apple Podcasts Specifications 2026',
      'Spotify Video Podcasting SDK'
    ]
  },
  distribution: {
    spotify: 'synced',
    apple: 'synced',
    youtube: 'draft',
    amazon: 'synced',
    rssUrl: 'https://feeds.resonatestudio.fm/techfrontier/rss.xml'
  },
  monetization: {
    monthlyDownloads: 48500,
    activeSponsorsCount: 3,
    averageCpm: 38.5,
    projectedRevenue: 5600,
    subscriberCount: 820,
    subscriberRevenue: 4100
  }
};
